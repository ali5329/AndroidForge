# چت ساده - پروژه اندروید (WebView + Firebase)

این پروژه آماده آپلود در **AndroidForge** است.

## ویژگی‌ها

- چت گروهی عمومی با Firebase Realtime Database
- نمایش تعداد کاربران آنلاین در بالای صفحه چت
- امکان ریپلای (پاسخ) به پیام‌ها
- رابط کاربری فارسی و RTL

## قبل از بیلد (خیلی مهم)

1. فایل `app/src/main/assets/www/app.js` را باز کن
2. قسمت `firebaseConfig` را با تنظیمات واقعی پروژه Firebase خودت عوض کن

```js
const firebaseConfig = {
  apiKey: "....",
  authDomain: "....",
  databaseURL: "....",
  projectId: "....",
  storageBucket: "....",
  messagingSenderId: "....",
  appId: "...."
};
```

3. مطمئن شو Realtime Database را در Firebase فعال کرده‌ای و قوانین را باز گذاشته‌ای (یا حداقل `presence` و `messages` قابل خواندن/نوشتن باشند).

نمونه قوانین ساده برای تست:

```json
{
  "rules": {
    ".read": true,
    ".write": true
  }
}
```

## آپلود در AndroidForge

کل پوشه را زیپ کن و در سایت AndroidForge آپلود کن.
سایت خودش با Gradle بیلد می‌گیرد و APK می‌دهد.
