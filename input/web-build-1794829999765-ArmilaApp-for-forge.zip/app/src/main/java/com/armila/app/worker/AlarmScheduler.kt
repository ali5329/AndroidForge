package com.armila.app.worker

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log

/**
 * Schedules the next romantic message using AlarmManager for more reliable
 * delivery than WorkManager when the app is in the background / Doze.
 */
object AlarmScheduler {

    private const val TAG = "ArmilaAlarm"
    const val REQUEST_CODE = 4101
    const val INTERVAL_MS = 60L * 60L * 1000L // 60 minutes

    fun scheduleNext(context: Context, fromTime: Long = System.currentTimeMillis()) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val triggerAt = fromTime + INTERVAL_MS

        val intent = Intent(context, MessageAlarmReceiver::class.java).apply {
            action = MessageAlarmReceiver.ACTION_DELIVER
        }
        val pi = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            when {
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.M -> {
                    // Most reliable while idle
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
                }
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT -> {
                    am.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pi)
                }
                else -> {
                    am.set(AlarmManager.RTC_WAKEUP, triggerAt, pi)
                }
            }
            Log.d(TAG, "Scheduled next message at $triggerAt")
        } catch (e: SecurityException) {
            // Exact alarm not allowed – fallback
            Log.w(TAG, "Exact alarm denied, falling back", e)
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
                } else {
                    am.set(AlarmManager.RTC_WAKEUP, triggerAt, pi)
                }
            } catch (e2: Exception) {
                Log.e(TAG, "Failed to schedule alarm", e2)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to schedule alarm", e)
        }
    }

    fun cancel(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, MessageAlarmReceiver::class.java).apply {
            action = MessageAlarmReceiver.ACTION_DELIVER
        }
        val pi = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.cancel(pi)
    }

    /** Call on app start / boot to ensure an alarm is pending. */
    fun ensureScheduled(context: Context) {
        scheduleNext(context)
    }
}
