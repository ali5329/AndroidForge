package com.armila.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.armila.app.data.MessageRepository
import com.armila.app.ui.MainScreen
import com.armila.app.ui.WelcomeScreen
import com.armila.app.ui.theme.ArmilaTheme
import com.armila.app.worker.AlarmScheduler
import com.armila.app.worker.MessageAlarmReceiver
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* handled silently */ }

    private lateinit var repository: MessageRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        repository = MessageRepository(this)

        // Notification permission (Android 13+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        // Schedule / refresh hourly alarm
        AlarmScheduler.ensureScheduled(this)

        // Ask to ignore battery optimizations once (critical for Xiaomi/Samsung etc.)
        requestIgnoreBatteryOptimizations()

        setContent {
            ArmilaTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    var showWelcome by remember { mutableStateOf(true) }
                    val scope = rememberCoroutineScope()

                    LaunchedEffect(Unit) {
                        val done = repository.isFirstLaunchDone()
                        if (done) {
                            showWelcome = false
                        }
                    }

                    if (showWelcome) {
                        WelcomeScreen(
                            onFinished = {
                                scope.launch {
                                    repository.markFirstLaunchDone()
                                    if (repository.getNextIndex() == 0L) {
                                        repository.deliverNextMessage()
                                    }
                                    // Start the hourly chain from now
                                    AlarmScheduler.scheduleNext(this@MainActivity)
                                    showWelcome = false
                                }
                            }
                        )
                    } else {
                        MainScreen()
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Refresh alarm in case it was lost
        AlarmScheduler.ensureScheduled(this)
        lifecycleScope.launch {
            try {
                repository.clearUnread()
                MessageAlarmReceiver.clearBadge(this@MainActivity)
            } catch (_: Exception) {
            }
        }
    }

    @SuppressLint("BatteryLife")
    private fun requestIgnoreBatteryOptimizations() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            }
        } catch (_: Exception) {
            // Some OEMs block this intent – user can set it manually
        }
    }
}
