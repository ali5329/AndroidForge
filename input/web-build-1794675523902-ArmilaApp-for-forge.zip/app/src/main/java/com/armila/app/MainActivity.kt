package com.armila.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.armila.app.data.MessageRepository
import com.armila.app.ui.MainScreen
import com.armila.app.ui.WelcomeScreen
import com.armila.app.ui.theme.ArmilaTheme
import com.armila.app.worker.MessageWorker
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* handled silently; user can still use the app */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Request notification permission on Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        // Ensure work is scheduled
        MessageWorker.schedule(this)

        setContent {
            ArmilaTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    var showWelcome by remember { mutableStateOf(true) }
                    val scope = rememberCoroutineScope()
                    val repository = remember { MessageRepository(this@MainActivity) }

                    LaunchedEffect(Unit) {
                        val done = repository.isFirstLaunchDone()
                        if (done) {
                            showWelcome = false
                        }
                    }

                    if (showWelcome) {
                        WelcomeScreen(
                            onFinished = {
                                scope.launch {
                                    repository.markFirstLaunchDone()
                                    // Deliver the very first message immediately on first launch
                                    if (repository.getNextIndex() == 0L) {
                                        repository.deliverNextMessage()
                                    }
                                    showWelcome = false
                                }
                            }
                        )
                    } else {
                        MainScreen()
                    }
                }
            }
        }
    }
}
