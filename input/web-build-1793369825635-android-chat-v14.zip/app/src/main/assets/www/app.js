// ============================================
// تنظیمات Firebase - این قسمت را با اطلاعات پروژه خودتان عوض کنید
// ============================================
const firebaseConfig = {
  apiKey: "AIzaSyBWkd5Zi_1Pb9zThRGun69VcOwYaNyDckw",
  authDomain: "sample-firebase-ai-app-f211a.firebaseapp.com",
  databaseURL: "https://sample-firebase-ai-app-f211a-default-rtdb.firebaseio.com",
  projectId: "sample-firebase-ai-app-f211a",
  storageBucket: "sample-firebase-ai-app-f211a.firebasestorage.app",
  messagingSenderId: "689511797055",
  appId: "1:689511797055:web:5269152f011d284962438a"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.database();
const messagesRef = db.ref('messages');
const presenceRef = db.ref('presence');
const privateRef = db.ref('privateChats');

// DOM
const loginScreen = document.getElementById('login-screen');
const chatScreen = document.getElementById('chat-screen');
const loginForm = document.getElementById('login-form');
const firstNameInput = document.getElementById('first-name');
const lastNameInput = document.getElementById('last-name');
const usernameInput = document.getElementById('username');
const messagesContainer = document.getElementById('messages');
const messageForm = document.getElementById('message-form');
const messageInput = document.getElementById('message-input');
const sendBtn = document.getElementById('send-btn');
const onlineCountEl = document.getElementById('online-count');
const onlineStatusEl = document.getElementById('online-status');
const replyBar = document.getElementById('reply-bar');
const replyToNameEl = document.getElementById('reply-to-name');
const replyToTextEl = document.getElementById('reply-to-text');
const cancelReplyBtn = document.getElementById('cancel-reply-btn');
const chatTitle = document.getElementById('chat-title');
const backBtn = document.getElementById('back-btn');
const privateSubtitle = document.getElementById('private-subtitle');

let currentUser = null;
let messagesListener = null;
let presenceListener = null;
let connectedListener = null;
let myPresenceRef = null;
let replyToMessage = null;

// حالت چت: 'public' یا 'private'
let chatMode = 'public';
let privatePartner = null; // { id, name }
let currentMessagesRef = messagesRef;

// ورود قبلی
const savedUser = localStorage.getItem('chatUser');
if (savedUser) {
  try {
    currentUser = JSON.parse(savedUser);
    if (!currentUser.username) {
      localStorage.removeItem('chatUser');
      currentUser = null;
    } else {
      showChat();
    }
  } catch (e) {
    localStorage.removeItem('chatUser');
  }
}

loginForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const firstName = firstNameInput.value.trim();
  const lastName = lastNameInput.value.trim();
  const username = usernameInput.value.trim();

  if (!firstName || !lastName || !username) return;

  if (!/^[A-Za-z0-9_\u0600-\u06FF]+$/.test(username)) {
    alert('نام کاربری فقط می‌تواند شامل حروف، عدد و _ باشد.');
    return;
  }

  currentUser = {
    firstName,
    lastName,
    username,
    fullName: `${firstName} ${lastName}`,
    displayName: username,
    id: Date.now().toString(36) + Math.random().toString(36).substr(2, 5)
  };

  localStorage.setItem('chatUser', JSON.stringify(currentUser));
  showChat();
});

function showChat() {
  loginScreen.classList.remove('active');
  chatScreen.classList.add('active');
  openPublicChat();
  setupPresence();
  messageInput.focus();
}

// ==================== چت عمومی / خصوصی ====================
function getPrivateChatId(userId1, userId2) {
  return [userId1, userId2].sort().join('_');
}

function openPublicChat() {
  // قطع لیسنر قبلی
  if (messagesListener && currentMessagesRef) {
    currentMessagesRef.off('child_added', messagesListener);
    messagesListener = null;
  }

  chatMode = 'public';
  privatePartner = null;
  currentMessagesRef = messagesRef;

  chatTitle.textContent = 'گروه عمومی';
  onlineStatusEl.classList.remove('hidden');
  privateSubtitle.classList.add('hidden');
  backBtn.classList.add('hidden');
  cancelReply();
  messageInput.placeholder = 'پیام خود را بنویسید...';

  loadMessages();
}

function openPrivateChat(partnerId, partnerName) {
  if (!partnerId || partnerId === currentUser.id) return;

  if (messagesListener && currentMessagesRef) {
    currentMessagesRef.off('child_added', messagesListener);
    messagesListener = null;
  }

  chatMode = 'private';
  privatePartner = { id: partnerId, name: partnerName };
  const chatId = getPrivateChatId(currentUser.id, partnerId);
  currentMessagesRef = privateRef.child(chatId).child('messages');

  // ذخیره اطلاعات طرف مقابل در چت
  privateRef.child(chatId).child('meta').update({
    users: {
      [currentUser.id]: currentUser.displayName || currentUser.username,
      [partnerId]: partnerName
    },
    updatedAt: firebase.database.ServerValue.TIMESTAMP
  });

  chatTitle.textContent = partnerName;
  onlineStatusEl.classList.add('hidden');
  privateSubtitle.classList.remove('hidden');
  backBtn.classList.remove('hidden');
  cancelReply();
  messageInput.placeholder = 'پیام خصوصی به ' + partnerName + '...';

  loadMessages();
  messageInput.focus();
}

backBtn.addEventListener('click', () => {
  openPublicChat();
});

// ==================== حضور آنلاین ====================
function setupPresence() {
  if (!currentUser) return;

  if (connectedListener) {
    db.ref('.info/connected').off('value', connectedListener);
  }
  if (presenceListener) {
    presenceRef.off('value', presenceListener);
  }

  const connectedRef = db.ref('.info/connected');
  connectedListener = connectedRef.on('value', (snap) => {
    if (snap.val() === true && currentUser) {
      myPresenceRef = presenceRef.child(currentUser.id);
      myPresenceRef.onDisconnect().remove().then(() => {
        myPresenceRef.set({
          name: currentUser.displayName || currentUser.username,
          lastSeen: firebase.database.ServerValue.TIMESTAMP
        });
      });
    }
  });

  presenceListener = presenceRef.on('value', (snapshot) => {
    let count = 0;
    if (snapshot.exists()) count = snapshot.numChildren();
    updateOnlineCount(count);
  }, (err) => {
    console.error('خطا در خواندن presence:', err);
    onlineCountEl.textContent = 'آفلاین';
  });
}

function updateOnlineCount(count) {
  if (count <= 0) {
    onlineCountEl.textContent = 'هیچ‌کس آنلاین نیست';
  } else if (count === 1) {
    onlineCountEl.textContent = '۱ نفر آنلاین';
  } else {
    onlineCountEl.textContent = toPersianNum(count) + ' نفر آنلاین';
  }
}

function stopPresence() {
  if (myPresenceRef) {
    myPresenceRef.remove().catch(() => {});
    myPresenceRef = null;
  }
}

function toPersianNum(n) {
  const persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return String(n).replace(/\d/g, (d) => persian[d]);
}

// ==================== پیام‌ها ====================
function loadMessages() {
  messagesContainer.innerHTML = '<div class="loading">در حال بارگذاری پیام‌ها...</div>';

  const ref = currentMessagesRef;
  ref.limitToLast(100).once('value', (snapshot) => {
    // اگر در این فاصله چت عوض شده، نادیده بگیر
    if (ref !== currentMessagesRef) return;

    messagesContainer.innerHTML = '';
    if (!snapshot.exists()) {
      const emptyText = chatMode === 'private'
        ? 'هنوز پیامی با این کاربر ندارید<br>اولین پیام را بفرستید!'
        : 'هنوز پیامی نیست<br>اولین پیام را بفرستید!';
      messagesContainer.innerHTML = `
        <div class="empty-state">
          <span>${chatMode === 'private' ? '🔒' : '💬'}</span>
          <p>${emptyText}</p>
        </div>
      `;
    } else {
      snapshot.forEach((child) => {
        appendMessage(child.val(), child.key);
      });
      scrollToBottom();
    }

    if (messagesListener) {
      ref.off('child_added', messagesListener);
    }
    messagesListener = ref.limitToLast(100).on('child_added', (snapshot) => {
      if (ref !== currentMessagesRef) return;
      if (document.querySelector(`[data-id="${snapshot.key}"]`)) return;

      const empty = messagesContainer.querySelector('.empty-state');
      if (empty) empty.remove();
      const loading = messagesContainer.querySelector('.loading');
      if (loading) loading.remove();

      appendMessage(snapshot.val(), snapshot.key);
      scrollToBottom();
    });
  }, (err) => {
    console.error('خطا در بارگذاری پیام‌ها:', err);
    messagesContainer.innerHTML = '<div class="loading">خطا در اتصال به سرور</div>';
  });
}

function appendMessage(msg, id) {
  const isMe = msg.userId === currentUser.id;
  const time = formatTime(msg.timestamp);

  const div = document.createElement('div');
  div.className = `message ${isMe ? 'me' : 'other'}`;
  div.dataset.id = id;

  let replyHtml = '';
  if (msg.replyTo) {
    const rName = escapeHtml(msg.replyTo.name || '');
    const rText = escapeHtml(msg.replyTo.text || '');
    const rId = escapeHtml(msg.replyTo.id || '');
    replyHtml = `
      <div class="reply-preview" data-reply-id="${rId}">
        <span class="reply-preview-name">${rName}</span>
        <span class="reply-preview-text">${rText}</span>
      </div>
    `;
  }

  const safeName = escapeHtml(msg.name || '');
  const safeText = escapeHtml(msg.text || '');
  const safeUserId = escapeHtml(msg.userId || '');

  // در چت عمومی نام قابل کلیک است (برای رفتن به پی‌وی)
  // روی پیام خودت کلیک نشود
  const nameClass = isMe ? 'message-name' : 'message-name clickable-name';
  const nameAttrs = isMe
    ? ''
    : `data-userid="${safeUserId}" data-username="${safeName}"`;

  div.innerHTML = `
    <div class="message-meta">
      <span class="${nameClass}" ${nameAttrs}>${safeName}</span>
      <span class="message-time">${time}</span>
    </div>
    <div class="message-bubble">
      ${replyHtml}
      ${safeText}
    </div>
    <div class="message-actions">
      <button type="button" class="btn-reply">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <polyline points="9 17 4 12 9 7"></polyline>
          <path d="M20 18v-2a4 4 0 0 0-4-4H4"></path>
        </svg>
        پاسخ
      </button>
    </div>
  `;

  // کلیک روی نام → چت خصوصی (فقط در گروه عمومی و فقط روی دیگران)
  if (!isMe && chatMode === 'public') {
    const nameEl = div.querySelector('.clickable-name');
    if (nameEl) {
      nameEl.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const uid = nameEl.dataset.userid;
        const uname = nameEl.dataset.username;
        if (uid && uname) {
          openPrivateChat(uid, uname);
        }
      });
    }
  }

  const replyBtn = div.querySelector('.btn-reply');
  replyBtn.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    setReplyTo({
      id: id,
      name: msg.name || '',
      text: msg.text || ''
    });
  });

  const replyPreview = div.querySelector('.reply-preview');
  if (replyPreview) {
    replyPreview.addEventListener('click', (e) => {
      e.stopPropagation();
      const targetId = replyPreview.dataset.replyId;
      if (targetId) {
        const target = document.querySelector(`[data-id="${targetId}"]`);
        if (target) {
          target.scrollIntoView({ behavior: 'smooth', block: 'center' });
          target.classList.add('highlight');
          setTimeout(() => target.classList.remove('highlight'), 1500);
        }
      }
    });
  }

  messagesContainer.appendChild(div);
}

// ==================== ریپلای ====================
function setReplyTo(msg) {
  replyToMessage = msg;
  replyToNameEl.textContent = msg.name;
  const shortText = msg.text.length > 40 ? msg.text.slice(0, 40) + '…' : msg.text;
  replyToTextEl.textContent = shortText;
  replyBar.classList.remove('hidden');
  messageInput.focus();
}

function cancelReply() {
  replyToMessage = null;
  replyBar.classList.add('hidden');
  replyToNameEl.textContent = '';
  replyToTextEl.textContent = '';
}

cancelReplyBtn.addEventListener('click', cancelReply);

// ارسال پیام
messageForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const text = messageInput.value.trim();
  if (!text || !currentUser) return;

  sendBtn.disabled = true;

  const displayName = currentUser.displayName || currentUser.username || currentUser.fullName;

  const message = {
    text: text,
    name: displayName,
    userId: currentUser.id,
    timestamp: firebase.database.ServerValue.TIMESTAMP
  };

  if (replyToMessage) {
    message.replyTo = {
      id: replyToMessage.id,
      name: replyToMessage.name,
      text: replyToMessage.text.length > 80
        ? replyToMessage.text.slice(0, 80) + '…'
        : replyToMessage.text
    };
  }

  currentMessagesRef.push(message)
    .then(() => {
      // آپدیت زمان آخرین پیام در چت خصوصی
      if (chatMode === 'private' && privatePartner) {
        const chatId = getPrivateChatId(currentUser.id, privatePartner.id);
        privateRef.child(chatId).child('meta').update({
          updatedAt: firebase.database.ServerValue.TIMESTAMP,
          lastMessage: text.length > 50 ? text.slice(0, 50) + '…' : text
        });
      }
      messageInput.value = '';
      sendBtn.disabled = true;
      cancelReply();
      messageInput.focus();
    })
    .catch((err) => {
      console.error('خطا در ارسال:', err);
      alert('خطا در ارسال پیام. اتصال اینترنت و تنظیمات Firebase را بررسی کنید.');
      sendBtn.disabled = false;
    });
});

messageInput.addEventListener('input', () => {
  sendBtn.disabled = messageInput.value.trim().length === 0;
});

function scrollToBottom() {
  requestAnimationFrame(() => {
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  });
}

function formatTime(timestamp) {
  if (!timestamp) return '';
  const date = new Date(timestamp);
  const now = new Date();
  const isToday = date.toDateString() === now.toDateString();
  const hours = date.getHours().toString().padStart(2, '0');
  const minutes = date.getMinutes().toString().padStart(2, '0');
  if (isToday) return `${hours}:${minutes}`;
  return `${date.getDate()}/${date.getMonth() + 1} ${hours}:${minutes}`;
}

function escapeHtml(text) {
  if (!text) return '';
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

messageInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    if (!sendBtn.disabled) {
      messageForm.dispatchEvent(new Event('submit'));
    }
  }
});

window.addEventListener('beforeunload', () => {
  stopPresence();
});

document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible' && currentUser && myPresenceRef) {
    myPresenceRef.set({
      name: currentUser.displayName || currentUser.username,
      lastSeen: firebase.database.ServerValue.TIMESTAMP
    });
  }
});
