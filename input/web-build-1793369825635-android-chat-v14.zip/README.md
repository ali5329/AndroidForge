# چت ساده - پروژه اندروید (WebView + Firebase)

نسخه ۱.۴ – آماده آپلود در AndroidForge

## ویژگی‌ها
- چت گروهی عمومی
- چت خصوصی (با کلیک روی نام کاربر)
- تعداد کاربران آنلاین
- ریپلای به پیام
- نام کاربری

## Firebase
در `app/src/main/assets/www/app.js` مقدار `firebaseConfig` را با پروژه خودت عوض کن.
قوانین Realtime Database باید باز باشند (حداقل برای messages, presence, privateChats).
