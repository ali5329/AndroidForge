const firebaseConfig = {
  apiKey: "AIzaSyBWkd5Zi_1Pb9zThRGun69VcOwYaNyDckw",
  authDomain: "sample-firebase-ai-app-f211a.firebaseapp.com",
  databaseURL: "https://sample-firebase-ai-app-f211a-default-rtdb.firebaseio.com",
  projectId: "sample-firebase-ai-app-f211a",
  storageBucket: "sample-firebase-ai-app-f211a.firebasestorage.app",
  messagingSenderId: "689511797055",
  appId: "1:689511797055:web:5269152f011d284962438a"
};

firebase.initializeApp(firebaseConfig);

// شناسه کاربران ادمین (از پنل ادمین هم می‌توان پیام با isAdmin فرستاد)
const ADMIN_IDS = JSON.parse(localStorage.getItem('adminIds') || '[]');
function isAdminUser(userId, msg) {
  if (msg && msg.isAdmin) return true;
  if (userId && ADMIN_IDS.indexOf(userId) !== -1) return true;
  return !!(msg && msg.admin);
}

const db = firebase.database();
const storage = firebase.storage();
const messagesRef = db.ref('messages');
const presenceRef = db.ref('presence');
const privateRef = db.ref('privateChats');
const privateInboxRoot = db.ref('privateInbox');

const loginScreen = document.getElementById('login-screen');
const chatScreen = document.getElementById('chat-screen');
const loginForm = document.getElementById('login-form');
const firstNameInput = document.getElementById('first-name');
const lastNameInput = document.getElementById('last-name');
const messagesContainer = document.getElementById('messages');
const messageForm = document.getElementById('message-form');
const messageInput = document.getElementById('message-input');
const sendBtn = document.getElementById('send-btn');
const onlineCountEl = document.getElementById('online-count');
const onlineStatusEl = document.getElementById('online-status');
const replyBar = document.getElementById('reply-bar');
const replyToNameEl = document.getElementById('reply-to-name');
const replyToTextEl = document.getElementById('reply-to-text');
const cancelReplyBtn = document.getElementById('cancel-reply-btn');
const chatTitle = document.getElementById('chat-title');
const backBtn = document.getElementById('back-btn');
const privateSubtitle = document.getElementById('private-subtitle');
const attachBtn = document.getElementById('attach-btn');
const imageInput = document.getElementById('image-input');
const imagePreviewBar = document.getElementById('image-preview-bar');
const imagePreviewThumb = document.getElementById('image-preview-thumb');
const imagePreviewName = document.getElementById('image-preview-name');
const cancelImageBtn = document.getElementById('cancel-image-btn');
const lightbox = document.getElementById('lightbox');
const lightboxImg = document.getElementById('lightbox-img');
const lightboxClose = document.getElementById('lightbox-close');
const voiceBtn = document.getElementById('voice-btn');
const voiceBar = document.getElementById('voice-bar');
const voiceTimerEl = document.getElementById('voice-timer');
const cancelVoiceBtn = document.getElementById('cancel-voice-btn');
const sendVoiceBtn = document.getElementById('send-voice-btn');
const actionModal = document.getElementById('action-modal');
const actionModalTitle = document.getElementById('action-modal-title');
const actionModalDesc = document.getElementById('action-modal-desc');
const actionModalEditWrap = document.getElementById('action-modal-edit-wrap');
const actionModalInput = document.getElementById('action-modal-input');
const actionModalCancel = document.getElementById('action-modal-cancel');
const actionModalConfirm = document.getElementById('action-modal-confirm');
const actionModalBackdrop = document.getElementById('action-modal-backdrop');
let modalResolve = null;
const profileBtn = document.getElementById('profile-btn');
const privateListBtn = document.getElementById('private-list-btn');
const privateListScreen = document.getElementById('private-list-screen');
const privateChatList = document.getElementById('private-chat-list');
const pmListBack = document.getElementById('pm-list-back');
const pmBadge = document.getElementById('pm-badge');
let privateInboxListener = null;

const headerAvatar = document.getElementById('header-avatar');
const headerAvatarFallback = document.getElementById('header-avatar-fallback');
const profileModal = document.getElementById('profile-modal');
const profileModalBackdrop = document.getElementById('profile-modal-backdrop');
const profileModalClose = document.getElementById('profile-modal-close');
const profileAvatarImg = document.getElementById('profile-avatar-img');
const profileAvatarFallback = document.getElementById('profile-avatar-fallback');
const profileNameEl = document.getElementById('profile-name');
const changeAvatarBtn = document.getElementById('change-avatar-btn');
const avatarInput = document.getElementById('avatar-input');
const profileRemoveAvatar = document.getElementById('profile-remove-avatar');



let currentUser = null;
let messagesListener = null;
let messagesChangedListener = null;
let messagesRemovedListener = null;

function detachMessagesListeners() {
  if (currentMessagesRef) {
    if (messagesListener) currentMessagesRef.off('child_added', messagesListener);
    if (messagesChangedListener) currentMessagesRef.off('child_changed', messagesChangedListener);
    if (messagesRemovedListener) currentMessagesRef.off('child_removed', messagesRemovedListener);
  }
  messagesListener = null;
  messagesChangedListener = null;
  messagesRemovedListener = null;
}
let presenceListener = null;
let connectedListener = null;
let myPresenceRef = null;
let replyToMessage = null;
let pendingImageFile = null;

let chatMode = 'public';
let privatePartner = null;
let currentMessagesRef = messagesRef;
let unreadCount = 0;
let appInForeground = true;
let lastKnownMessageKey = null;
let isInitialLoad = true;
let adminIds = {};

// لیست ادمین‌ها از Firebase
db.ref('admins').on('value', (snap) => {
  adminIds = {};
  if (snap.exists()) {
    snap.forEach((c) => { adminIds[c.key] = true; });
  }
  // بروزرسانی تیک آبی روی پیام‌های موجود
  document.querySelectorAll('.message').forEach((el) => {
    const uid = el.dataset.userid;
    const tick = el.querySelector('.admin-tick');
    if (!tick) return;
    tick.classList.toggle('hidden', !adminIds[uid]);
  });
});


// Voice
let mediaRecorder = null;
let audioChunks = [];
let recordingStart = 0;
let voiceTimerInterval = null;
let recordedBlob = null;
let recordedDuration = 0;
let currentAudio = null;

const savedUser = localStorage.getItem('chatUser');
if (savedUser) {
  try {
    currentUser = JSON.parse(savedUser);
    if (!currentUser.fullName && currentUser.firstName) {
      currentUser.fullName = `${currentUser.firstName} ${currentUser.lastName || ''}`.trim();
    }
    showChat();
  } catch (e) { localStorage.removeItem('chatUser'); }
}

loginForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const firstName = firstNameInput.value.trim();
  const lastName = lastNameInput.value.trim();
  if (!firstName || !lastName) return;
  currentUser = {
    firstName, lastName,
    fullName: `${firstName} ${lastName}`,
    displayName: `${firstName} ${lastName}`,
    id: Date.now().toString(36) + Math.random().toString(36).substr(2, 5)
  };
  localStorage.setItem('chatUser', JSON.stringify(currentUser));
  showChat();
});

function showChat() {
  loginScreen.classList.remove('active');
  if (privateListScreen) privateListScreen.classList.remove('active');
  chatScreen.classList.add('active');
  updateAvatarUI();
  openPublicChat();
  setupPresence();
  setupPrivateInboxListener();
  messageInput.focus();
}

function getPrivateChatId(a, b) { return [a, b].sort().join('_'); }

function updatePrivateInbox(partnerId, partnerName, partnerAvatar, lastMessage, forPeerUnread) {
  if (!currentUser || !partnerId) return;
  const chatId = getPrivateChatId(currentUser.id, partnerId);
  privateInboxRoot.child(currentUser.id).child(chatId).transaction((cur) => {
    const base = cur || {};
    const next = Object.assign({}, base, {
      chatId,
      peerId: partnerId,
      peerName: partnerName || base.peerName || 'کاربر',
      peerAvatar: partnerAvatar || base.peerAvatar || null,
      updatedAt: Date.now(),
      unread: 0
    });
    if (lastMessage) next.lastMessage = lastMessage;
    else if (!next.lastMessage) next.lastMessage = '';
    return next;
  });
  privateInboxRoot.child(partnerId).child(chatId).transaction((cur) => {
    const base = cur || {};
    const unread = forPeerUnread ? ((base.unread || 0) + 1) : (base.unread || 0);
    const next = Object.assign({}, base, {
      chatId,
      peerId: currentUser.id,
      peerName: currentUser.fullName || currentUser.displayName || 'کاربر',
      peerAvatar: currentUser.avatar || null,
      updatedAt: Date.now(),
      unread
    });
    if (lastMessage) next.lastMessage = lastMessage;
    else if (!next.lastMessage) next.lastMessage = '';
    return next;
  });
}

function clearPrivateUnread(partnerId) {
  if (!currentUser || !partnerId) return;
  const chatId = getPrivateChatId(currentUser.id, partnerId);
  privateInboxRoot.child(currentUser.id).child(chatId).child('unread').set(0).catch(() => {});
}

function setupPrivateInboxListener() {
  if (!currentUser) return;
  if (privateInboxListener) {
    privateInboxRoot.child(currentUser.id).off('value', privateInboxListener);
  }
  privateInboxListener = privateInboxRoot.child(currentUser.id).on('value', (snap) => {
    let totalUnread = 0;
    const items = [];
    if (snap.exists()) {
      snap.forEach((c) => {
        const v = c.val() || {};
        items.push(v);
        totalUnread += (v.unread || 0);
      });
    }
    items.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
    if (pmBadge) {
      if (totalUnread > 0) {
        pmBadge.textContent = totalUnread > 99 ? '99+' : String(totalUnread);
        pmBadge.classList.remove('hidden');
      } else {
        pmBadge.classList.add('hidden');
      }
    }
    // اگر صفحه لیست باز است رندر کن
    if (privateListScreen && privateListScreen.classList.contains('active')) {
      renderPrivateList(items);
    }
    // cache for when opening list
    window.__pmListCache = items;
  });
}

function renderPrivateList(items) {
  if (!privateChatList) return;
  if (!items || !items.length) {
    privateChatList.innerHTML = `<div class="pm-empty"><span>💬</span><p>هنوز چت خصوصی ندارید.<br>روی نام یا عکس کاربر در گروه بزنید.</p></div>`;
    return;
  }
  privateChatList.innerHTML = items.map((it) => {
    const name = escapeHtml(it.peerName || 'کاربر');
    const last = escapeHtml(it.lastMessage || '');
    const time = formatTime(it.updatedAt);
    const unread = it.unread || 0;
    const av = it.peerAvatar
      ? `<img class="pm-item-avatar" src="${escapeHtml(it.peerAvatar)}" alt="">`
      : `<div class="pm-item-avatar-fallback">${(it.peerName || '?').charAt(0)}</div>`;
    return `<div class="pm-item" data-peer-id="${escapeHtml(it.peerId || '')}" data-peer-name="${name}">
      ${av}
      <div class="pm-item-body">
        <div class="pm-item-top">
          <span class="pm-item-name">${name}</span>
          <span class="pm-item-time">${time}</span>
        </div>
        <div class="pm-item-bottom">
          <span class="pm-item-last">${last}</span>
          <span class="pm-item-unread ${unread ? '' : 'hidden'}">${unread > 99 ? '99+' : unread}</span>
        </div>
      </div>
    </div>`;
  }).join('');

  privateChatList.querySelectorAll('.pm-item').forEach((el) => {
    el.addEventListener('click', () => {
      const pid = el.dataset.peerId;
      const pname = el.dataset.peerName;
      if (pid) openPrivateChat(pid, pname);
    });
  });
}

function showPrivateList() {
  // hide other screens
  loginScreen.classList.remove('active');
  chatScreen.classList.remove('active');
  privateListScreen.classList.add('active');
  renderPrivateList(window.__pmListCache || []);
}

function hidePrivateListToPublic() {
  privateListScreen.classList.remove('active');
  chatScreen.classList.add('active');
  openPublicChat();
}



function openPublicChat() {
  detachMessagesListeners();
  chatMode = 'public';
  privatePartner = null;
  currentMessagesRef = messagesRef;
  isInitialLoad = true;
  stopPartnerPresence();
  chatTitle.textContent = 'Classik,chat';
  onlineStatusEl.classList.remove('hidden');
  onlineStatusEl.classList.remove('offline');
  privateSubtitle.classList.add('hidden');
  backBtn.classList.add('hidden');
  // بازگرداندن شمارنده گروهی
  presenceRef.once('value', (snapshot) => {
    let count = 0;
    if (snapshot.exists()) snapshot.forEach((c) => {
      const v = c.val() || {};
      if (v.online === true || (v.online === undefined && v.name)) count++;
    });
    updateOnlineCount(count);
  });
  cancelReply();
  clearPendingImage();
  stopRecording(false);
  messageInput.placeholder = 'پیام خود را بنویسید...';
  loadMessages();
  clearUnreadBadge();
  setTimeout(markVisibleMessagesRead, 800);
}

function openPrivateChat(partnerId, partnerName, partnerAvatar) {
  if (!partnerId || partnerId === currentUser.id) return;
  detachMessagesListeners();
  if (privateListScreen) privateListScreen.classList.remove('active');
  chatScreen.classList.add('active');
  chatMode = 'private';
  privatePartner = { id: partnerId, name: partnerName, avatar: partnerAvatar || null };
  const chatId = getPrivateChatId(currentUser.id, partnerId);
  currentMessagesRef = privateRef.child(chatId).child('messages');
  isInitialLoad = true;
  privateRef.child(chatId).child('meta').update({
    users: {
      [currentUser.id]: currentUser.fullName,
      [partnerId]: partnerName
    },
    userAvatars: {
      [currentUser.id]: currentUser.avatar || null,
      [partnerId]: partnerAvatar || null
    },
    updatedAt: firebase.database.ServerValue.TIMESTAMP
  });
  // ensure inbox entries exist
  updatePrivateInbox(partnerId, partnerName, partnerAvatar, null, false);
  clearPrivateUnread(partnerId);
  chatTitle.textContent = partnerName;
  privateSubtitle.classList.add('hidden');
  onlineStatusEl.classList.remove('hidden');
  onlineCountEl.textContent = 'در حال بررسی...';
  backBtn.classList.remove('hidden');
  cancelReply();
  clearPendingImage();
  stopRecording(false);
  messageInput.placeholder = 'پیام خصوصی به ' + partnerName + '...';
  watchPartnerPresence(partnerId);
  loadMessages();
  messageInput.focus();
  setTimeout(markVisibleMessagesRead, 800);
}

backBtn.addEventListener('click', () => openPublicChat());

if (privateListBtn) {
  privateListBtn.addEventListener('click', () => {
    if (!currentUser) return;
    showPrivateList();
  });
}
if (pmListBack) {
  pmListBack.addEventListener('click', () => {
    hidePrivateListToPublic();
  });
}


let partnerPresenceListener = null;

function setupPresence() {
  if (!currentUser) return;
  if (connectedListener) db.ref('.info/connected').off('value', connectedListener);
  if (presenceListener) presenceRef.off('value', presenceListener);
  connectedListener = db.ref('.info/connected').on('value', (snap) => {
    if (snap.val() === true && currentUser) {
      myPresenceRef = presenceRef.child(currentUser.id);
      myPresenceRef.onDisconnect().set({
        name: currentUser.fullName,
        online: false,
        lastSeen: firebase.database.ServerValue.TIMESTAMP
      }).then(() => {
        myPresenceRef.set({
          name: currentUser.fullName,
          online: true,
          lastSeen: firebase.database.ServerValue.TIMESTAMP
        });
      });
    }
  });
  presenceListener = presenceRef.on('value', (snapshot) => {
    let count = 0;
    if (snapshot.exists()) {
      snapshot.forEach((c) => {
        const v = c.val() || {};
        // سازگاری با نسخه قدیم: اگر فقط name بود یعنی آنلاین
        if (v.online === true || (v.online === undefined && v.name)) count++;
      });
    }
    updateOnlineCount(count);
  }, () => { onlineCountEl.textContent = 'آفلاین'; });
}

function updateOnlineCount(count) {
  if (count <= 0) onlineCountEl.textContent = 'هیچ‌کس آنلاین نیست';
  else if (count === 1) onlineCountEl.textContent = '۱ نفر آنلاین';
  else onlineCountEl.textContent = toPersianNum(count) + ' نفر آنلاین';
}

function stopPresence() {
  if (myPresenceRef) {
    myPresenceRef.set({
      name: currentUser ? currentUser.fullName : '',
      online: false,
      lastSeen: firebase.database.ServerValue.TIMESTAMP
    }).catch(() => {});
    myPresenceRef = null;
  }
  stopPartnerPresence();
}

function stopPartnerPresence() {
  if (partnerPresenceListener && privatePartner) {
    presenceRef.child(privatePartner.id).off('value', partnerPresenceListener);
  }
  partnerPresenceListener = null;
}

function formatLastSeen(ts) {
  if (!ts) return 'آخرین بازدید نامشخص';
  const d = new Date(ts);
  const now = new Date();
  const diff = now - d;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'آخرین بازدید همین الان';
  if (mins < 60) return 'آخرین بازدید ' + toPersianNum(mins) + ' دقیقه پیش';
  const hours = Math.floor(mins / 60);
  if (hours < 24) return 'آخرین بازدید ' + toPersianNum(hours) + ' ساعت پیش';
  const days = Math.floor(hours / 24);
  if (days === 1) return 'آخرین بازدید دیروز';
  if (days < 7) return 'آخرین بازدید ' + toPersianNum(days) + ' روز پیش';
  const h = d.getHours().toString().padStart(2, '0');
  const m = d.getMinutes().toString().padStart(2, '0');
  return 'آخرین بازدید ' + d.getDate() + '/' + (d.getMonth() + 1) + ' ساعت ' + h + ':' + m;
}

function watchPartnerPresence(partnerId) {
  stopPartnerPresence();
  if (!partnerId) return;
  partnerPresenceListener = presenceRef.child(partnerId).on('value', (snap) => {
    if (chatMode !== 'private' || !privatePartner || privatePartner.id !== partnerId) return;
    const el = document.getElementById('online-count');
    const statusWrap = document.getElementById('online-status');
    const sub = document.getElementById('private-subtitle');
    if (!el) return;
    // در پی‌وی: status را نشان بده
    if (statusWrap) statusWrap.classList.remove('hidden');
    if (sub) sub.classList.add('hidden');
    if (!snap.exists()) {
      el.textContent = 'آخرین بازدید نامشخص';
      if (statusWrap) statusWrap.classList.add('offline');
      return;
    }
    const v = snap.val() || {};
    const isOn = v.online === true || (v.online === undefined && v.name && !v.lastSeen);
    // اگر online صریح true یا (قدیمی و فقط name بدون lastSeen بعد از disconnect)
    if (v.online === true) {
      el.textContent = 'آنلاین';
      if (statusWrap) statusWrap.classList.remove('offline');
    } else {
      el.textContent = formatLastSeen(v.lastSeen);
      if (statusWrap) statusWrap.classList.add('offline');
    }
  });
}
function toPersianNum(n) {
  const p = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
  return String(n).replace(/\d/g, d => p[d]);
}

function updateAvatarUI() {
  const av = (currentUser && currentUser.avatar) || '';
  if (av) {
    if (headerAvatar) {
      headerAvatar.src = av;
      headerAvatar.classList.remove('hidden');
    }
    if (headerAvatarFallback) headerAvatarFallback.classList.add('hidden');
    if (profileAvatarImg) {
      profileAvatarImg.src = av;
      profileAvatarImg.classList.remove('hidden');
    }
    if (profileAvatarFallback) profileAvatarFallback.classList.add('hidden');
  } else {
    if (headerAvatar) {
      headerAvatar.src = '';
      headerAvatar.classList.add('hidden');
    }
    if (headerAvatarFallback) headerAvatarFallback.classList.remove('hidden');
    if (profileAvatarImg) {
      profileAvatarImg.src = '';
      profileAvatarImg.classList.add('hidden');
    }
    if (profileAvatarFallback) profileAvatarFallback.classList.remove('hidden');
  }
  if (profileNameEl && currentUser) {
    profileNameEl.textContent = currentUser.fullName || 'پروفایل';
  }
}

function openProfileModal() {
  if (!currentUser) return;
  updateAvatarUI();
  profileModal.classList.remove('hidden');
}
function closeProfileModal() {
  profileModal.classList.add('hidden');
}

if (profileBtn) profileBtn.addEventListener('click', openProfileModal);
if (profileModalClose) profileModalClose.addEventListener('click', closeProfileModal);
if (profileModalBackdrop) profileModalBackdrop.addEventListener('click', closeProfileModal);

if (changeAvatarBtn) {
  changeAvatarBtn.addEventListener('click', () => {
    if (avatarInput) {
      avatarInput.value = '';
      avatarInput.click();
    }
  });
}

if (avatarInput) {
  avatarInput.addEventListener('change', async () => {
    const file = avatarInput.files && avatarInput.files[0];
    if (!file || !currentUser) return;
    if (!file.type.startsWith('image/')) {
      await showActionModal({ title: 'خطا', desc: 'فقط فایل تصویری مجاز است.', confirmText: 'باشه' });
      return;
    }
    try {
      const compressed = await compressImage(file, 240, 0.55);
      if (compressed.size > 120 * 1024) {
        const smaller = await compressImage(file, 180, 0.4);
        const dataUrl = await blobToDataUrl(smaller);
        saveAvatar(dataUrl);
      } else {
        const dataUrl = await blobToDataUrl(compressed);
        saveAvatar(dataUrl);
      }
    } catch (err) {
      console.error(err);
      await showActionModal({ title: 'خطا', desc: 'بارگذاری عکس پروفایل ناموفق بود.', confirmText: 'باشه', danger: true });
    }
  });
}

function saveAvatar(dataUrl) {
  if (!currentUser) return;
  currentUser.avatar = dataUrl;
  localStorage.setItem('chatUser', JSON.stringify(currentUser));
  // ذخیره در Firebase برای دیگران
  db.ref('users/' + currentUser.id).update({
    name: currentUser.fullName,
    avatar: dataUrl,
    updatedAt: firebase.database.ServerValue.TIMESTAMP
  }).catch(() => {});
  updateAvatarUI();
}

if (profileRemoveAvatar) {
  profileRemoveAvatar.addEventListener('click', async () => {
    if (!currentUser) return;
    const ok = await showActionModal({
      title: 'حذف عکس پروفایل',
      desc: 'عکس پروفایلت حذف شود؟',
      confirmText: 'حذف کن',
      danger: true
    });
    if (!ok) return;
    delete currentUser.avatar;
    localStorage.setItem('chatUser', JSON.stringify(currentUser));
    db.ref('users/' + currentUser.id).update({
      avatar: null,
      updatedAt: firebase.database.ServerValue.TIMESTAMP
    }).catch(() => {});
    updateAvatarUI();
  });
}



function loadMessages() {
  messagesContainer.innerHTML = '<div class="loading">در حال بارگذاری پیام‌ها...</div>';
  const ref = currentMessagesRef;
  detachMessagesListeners();
  ref.limitToLast(100).once('value', (snapshot) => {
    if (ref !== currentMessagesRef) return;
    messagesContainer.innerHTML = '';
    if (!snapshot.exists()) {
      messagesContainer.innerHTML = `<div class="empty-state"><span>${chatMode === 'private' ? '🔒' : '💬'}</span>
        <p>${chatMode === 'private' ? 'هنوز پیامی با این کاربر ندارید<br>اولین پیام را بفرستید!' : 'هنوز پیامی نیست<br>اولین پیام را بفرستید!'}</p></div>`;
    } else {
      snapshot.forEach((child) => {
        const m = child.val();
        appendMessage(m, child.key);
        lastKnownMessageKey = child.key;
        if (m && m.userId !== currentUser.id) {
          acknowledgeMessage(ref, child.key, m, true);
        }
      });
      scrollToBottom();
    }
    isInitialLoad = false;

    messagesListener = ref.limitToLast(100).on('child_added', (snap) => {
      if (ref !== currentMessagesRef) return;
      if (document.querySelector(`[data-id="${snap.key}"]`)) return;
      const empty = messagesContainer.querySelector('.empty-state');
      if (empty) empty.remove();
      const loading = messagesContainer.querySelector('.loading');
      if (loading) loading.remove();
      const msg = snap.val();
      appendMessage(msg, snap.key);
      scrollToBottom();
      if (msg.userId !== currentUser.id) {
        acknowledgeMessage(ref, snap.key, msg, appInForeground && document.visibilityState === 'visible');
      }
      if (!isInitialLoad && msg.userId !== currentUser.id) {
        if (chatMode === 'public' || !appInForeground) onNewMessageNotification(msg);
      }
      lastKnownMessageKey = snap.key;
    });

    messagesChangedListener = ref.on('child_changed', (snap) => {
      if (ref !== currentMessagesRef) return;
      const existing = document.querySelector(`[data-id="${snap.key}"]`);
      const msg = snap.val();
      if (existing && msg) {
        // فقط تیک‌ها / متن ویرایش را درجا آپدیت کن تا ترتیب به‌هم نریزد
        if (msg.userId === currentUser.id) {
          updateMessageTicks(existing, msg.status || 'sent');
        }
        const textEl = existing.querySelector('.message-text');
        if (textEl && msg.text != null) textEl.textContent = msg.text;
        let edited = existing.querySelector('.edited-badge');
        if (msg.edited && !edited) {
          const meta = existing.querySelector('.message-meta');
          if (meta) {
            const span = document.createElement('span');
            span.className = 'edited-badge';
            span.textContent = 'ویرایش‌شده';
            meta.appendChild(span);
          }
        }
      } else if (msg) {
        appendMessage(msg, snap.key);
      }
    });

    messagesRemovedListener = ref.on('child_removed', (snap) => {
      if (ref !== currentMessagesRef) return;
      const existing = document.querySelector(`[data-id="${snap.key}"]`);
      if (existing) existing.remove();
      if (!messagesContainer.querySelector('.message')) {
        messagesContainer.innerHTML = `<div class="empty-state"><span>${chatMode === 'private' ? '🔒' : '💬'}</span>
          <p>${chatMode === 'private' ? 'هنوز پیامی با این کاربر ندارید<br>اولین پیام را بفرستید!' : 'هنوز پیامی نیست<br>اولین پیام را بفرستید!'}</p></div>`;
      }
    });
  }, () => { messagesContainer.innerHTML = '<div class="loading">خطا در اتصال به سرور</div>'; });
}

function appendMessage(msg, id) {
  const isMe = msg.userId === currentUser.id;
  const isAdminUser = !!(msg.isAdmin || (typeof adminIds !== 'undefined' && adminIds[msg.userId]));
  const time = formatTime(msg.timestamp);
  const div = document.createElement('div');
  div.className = `message ${isMe ? 'me' : 'other'}${isAdminUser ? ' is-admin' : ''}`;
  div.dataset.id = id;
  div.dataset.userid = msg.userId || '';

  let replyHtml = '';
  if (msg.replyTo) {
    replyHtml = `<div class="reply-preview" data-reply-id="${escapeHtml(msg.replyTo.id || '')}">
      <span class="reply-preview-name">${escapeHtml(msg.replyTo.name || '')}</span>
      <span class="reply-preview-text">${escapeHtml(msg.replyTo.text || '')}</span></div>`;
  }

  let contentHtml = '';
  const imgSrc = msg.imageUrl || msg.imageBase64 || '';
  if (imgSrc) {
    contentHtml += `<img class="message-image" src="${escapeHtml(imgSrc)}" alt="عکس" loading="lazy">`;
  }
  if (msg.voiceUrl) {
    const totalDur = msg.voiceDuration ? formatDuration(msg.voiceDuration) : '۰:۰۰';
    contentHtml += `<div class="voice-message" data-duration="${msg.voiceDuration || 0}">
      <button type="button" class="btn-play-voice" aria-label="پخش">
        <svg class="icon-play" width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
        <svg class="icon-pause hidden" width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>
      </button>
      <div class="voice-wave"><div class="voice-wave-progress"></div></div>
      <span class="voice-duration"><span class="voice-cur">۰:۰۰</span><span class="voice-sep"> / </span><span class="voice-total">${totalDur}</span></span>
    </div>`;
  }
  if (msg.text) contentHtml += `<div class="message-text">${escapeHtml(msg.text)}</div>`;

  const safeName = escapeHtml(msg.name || '');
  const safeUserId = escapeHtml(msg.userId || '');
  const nameClass = isMe ? 'message-name' : 'message-name clickable-name';
  const nameAttrs = isMe ? '' : `data-userid="${safeUserId}" data-username="${safeName}"`;
  const adminBadge = isAdminUser
    ? '<span class="admin-badge" title="مدیر"><svg width="14" height="14" viewBox="0 0 24 24" fill="#1d9bf0"><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm-1.1 14.5l-4.2-4.2 1.4-1.4 2.8 2.8 5.6-5.6 1.4 1.4-7 7z"/></svg></span><span class="admin-label">مدیر</span>'
    : '';
  const adminBubbleClass = isAdminUser ? ' admin-bubble' : '';

  const editedBadge = msg.edited ? '<span class="edited-badge">ویرایش‌شده</span>' : '';
  const ownActions = isMe ? `
      <button type="button" class="btn-edit" title="ویرایش">ویرایش</button>
      <button type="button" class="btn-delete" title="حذف">حذف</button>` : '';

  const avatarSrc = msg.avatar || '';
  const avatarHtml = avatarSrc
    ? `<img class="msg-avatar" src="${escapeHtml(avatarSrc)}" alt="">`
    : `<div class="msg-avatar-fallback">${(msg.name || '?').charAt(0)}</div>`;

  div.innerHTML = `
    <div class="message-row">
      ${avatarHtml}
      <div class="message-body">
        <div class="message-meta">
          <span class="${nameClass}" ${nameAttrs}>${safeName}</span>
          ${adminBadge}
          <span class="message-time">${time}</span>
          ${editedBadge}
          ${isMe ? statusTicksHtml(msg.status || 'sent') : ''}
        </div>
        <div class="message-bubble${adminBubbleClass}">${replyHtml}${contentHtml}</div>
        <div class="message-actions">
          <button type="button" class="btn-reply">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="9 17 4 12 9 7"></polyline>
              <path d="M20 18v-2a4 4 0 0 0-4-4H4"></path>
            </svg> پاسخ
          </button>
          ${ownActions}
        </div>
      </div>
    </div>`;

  if (!isMe && chatMode === 'public') {
    const openPm = (e) => {
      e.preventDefault(); e.stopPropagation();
      openPrivateChat(msg.userId, msg.name || '', msg.avatar || null);
    };
    const nameEl = div.querySelector('.clickable-name');
    if (nameEl) nameEl.addEventListener('click', openPm);
    const avImg = div.querySelector('.msg-avatar');
    const avFb = div.querySelector('.msg-avatar-fallback');
    if (avImg) avImg.addEventListener('click', openPm);
    if (avFb) avFb.addEventListener('click', openPm);
  }

  const imgEl = div.querySelector('.message-image');
  if (imgEl) imgEl.addEventListener('click', () => openLightbox(imgSrc));

  const playBtn = div.querySelector('.btn-play-voice');
  if (playBtn && msg.voiceUrl) {
    playBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const wrap = playBtn.closest('.voice-message');
      playVoice(msg.voiceUrl, playBtn, wrap);
    });
  }

  div.querySelector('.btn-reply').addEventListener('click', (e) => {
    e.preventDefault(); e.stopPropagation();
    let preview = msg.text || '';
    if (!preview && (msg.imageUrl || msg.imageBase64)) preview = '📷 عکس';
    if (!preview && msg.voiceUrl) preview = '🎤 ویس';
    setReplyTo({ id, name: msg.name || '', text: preview });
  });

  const editBtn = div.querySelector('.btn-edit');
  if (editBtn) {
    editBtn.addEventListener('click', (e) => {
      e.preventDefault(); e.stopPropagation();
      editMessage(id, msg);
    });
  }
  const delBtn = div.querySelector('.btn-delete');
  if (delBtn) {
    delBtn.addEventListener('click', (e) => {
      e.preventDefault(); e.stopPropagation();
      deleteMessage(id, msg);
    });
  }

  const rp = div.querySelector('.reply-preview');
  if (rp) {
    rp.addEventListener('click', (e) => {
      e.stopPropagation();
      const t = document.querySelector(`[data-id="${rp.dataset.replyId}"]`);
      if (t) {
        t.scrollIntoView({ behavior: 'smooth', block: 'center' });
        t.classList.add('highlight');
        setTimeout(() => t.classList.remove('highlight'), 1500);
      }
    });
  }

  messagesContainer.appendChild(div);
}

// ===== Image =====
attachBtn.addEventListener('click', () => {
  imageInput.value = '';
  imageInput.click();
});

imageInput.addEventListener('change', () => {
  const file = imageInput.files && imageInput.files[0];
  if (!file) return;
  if (!file.type.startsWith('image/')) { alert('فقط فایل تصویری مجاز است.'); return; }
  if (file.size > 8 * 1024 * 1024) { alert('حجم عکس نباید بیشتر از ۸ مگابایت باشد.'); return; }
  pendingImageFile = file;
  const reader = new FileReader();
  reader.onload = (e) => {
    imagePreviewThumb.src = e.target.result;
    imagePreviewName.textContent = file.name || 'عکس';
    imagePreviewBar.classList.remove('hidden');
    sendBtn.disabled = false;
  };
  reader.readAsDataURL(file);
});

cancelImageBtn.addEventListener('click', clearPendingImage);
function clearPendingImage() {
  pendingImageFile = null;
  imageInput.value = '';
  imagePreviewBar.classList.add('hidden');
  imagePreviewThumb.src = '';
  sendBtn.disabled = messageInput.value.trim().length === 0;
}

function compressImage(file, maxWidth, quality) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      URL.revokeObjectURL(url);
      let w = img.width, h = img.height;
      if (w > maxWidth) { h = Math.round(h * maxWidth / w); w = maxWidth; }
      const canvas = document.createElement('canvas');
      canvas.width = w; canvas.height = h;
      canvas.getContext('2d').drawImage(img, 0, 0, w, h);
      canvas.toBlob((blob) => blob ? resolve(blob) : reject(new Error('فشردهسازی ناموفق')), 'image/jpeg', quality);
    };
    img.onerror = () => reject(new Error('خواندن عکس ناموفق'));
    img.src = url;
  });
}

// تبدیل فایل به base64 (بدون نیاز به Firebase Storage)
function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}


function setUploadProgress(pct) {
  const wrap = document.getElementById('upload-progress-wrap');
  const bar = document.getElementById('upload-progress-bar');
  const txt = document.getElementById('upload-progress-text');
  if (!wrap || !bar || !txt) return;
  const p = Math.max(0, Math.min(100, Math.round(pct)));
  wrap.classList.remove('hidden');
  txt.classList.remove('hidden');
  bar.style.width = p + '%';
  const persian = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
  txt.textContent = String(p).replace(/\d/g, d => persian[d]) + '٪';
}

function hideUploadProgress() {
  const wrap = document.getElementById('upload-progress-wrap');
  const bar = document.getElementById('upload-progress-bar');
  const txt = document.getElementById('upload-progress-text');
  if (wrap) wrap.classList.add('hidden');
  if (txt) txt.classList.add('hidden');
  if (bar) bar.style.width = '0%';
}

async function uploadImageWithProgress(file) {
  setUploadProgress(5);
  await new Promise(r => setTimeout(r, 40));
  setUploadProgress(20);
  const compressed = await compressImage(file, 900, 0.55);
  setUploadProgress(55);
  let blob = compressed;
  if (compressed.size > 450 * 1024) {
    setUploadProgress(65);
    blob = await compressImage(file, 700, 0.4);
    if (blob.size > 450 * 1024) throw new Error('عکس خیلی بزرگ است. عکس کوچک‌تری انتخاب کنید.');
  }
  setUploadProgress(80);
  const dataUrl = await blobToDataUrl(blob);
  setUploadProgress(95);
  await new Promise(r => setTimeout(r, 80));
  setUploadProgress(100);
  await new Promise(r => setTimeout(r, 150));
  return dataUrl;
}

async function uploadImage(file) {
  // فشرده‌سازی قوی تا برای Realtime Database مناسب باشد
  const compressed = await compressImage(file, 900, 0.55);
  if (compressed.size > 450 * 1024) {
    // دوباره با کیفیت کمتر
    const smaller = await compressImage(file, 700, 0.4);
    if (smaller.size > 450 * 1024) {
      throw new Error('عکس خیلی بزرگ است. عکس کوچک‌تری انتخاب کنید.');
    }
    return await blobToDataUrl(smaller);
  }
  return await blobToDataUrl(compressed);
}

function openLightbox(url) {
  lightboxImg.src = url;
  lightbox.classList.remove('hidden');
}
lightboxClose.addEventListener('click', () => { lightbox.classList.add('hidden'); lightboxImg.src = ''; });
lightbox.addEventListener('click', (e) => { if (e.target === lightbox) { lightbox.classList.add('hidden'); lightboxImg.src = ''; } });

// ===== Voice =====
voiceBtn.addEventListener('click', async () => {
  if (mediaRecorder && mediaRecorder.state === 'recording') {
    stopRecording(true);
    return;
  }
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    audioChunks = [];
    recordedBlob = null;
    recordedDuration = 0;

    // اولویت با فرمت‌هایی که روی اندروید بهتر پخش می‌شوند
    let mime = '';
    const candidates = [
      'audio/mp4',
      'audio/aac',
      'audio/webm;codecs=opus',
      'audio/webm',
      'audio/ogg;codecs=opus',
      'audio/ogg'
    ];
    for (const c of candidates) {
      if (window.MediaRecorder && MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(c)) {
        mime = c;
        break;
      }
    }

    try {
      mediaRecorder = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream);
    } catch (e) {
      mediaRecorder = new MediaRecorder(stream);
    }
    audioChunks = [];
    mediaRecorder.ondataavailable = (e) => { if (e.data && e.data.size > 0) audioChunks.push(e.data); };
    mediaRecorder.onstop = () => {
      stream.getTracks().forEach(t => t.stop());
      const type = (mediaRecorder && mediaRecorder.mimeType) || mime || 'audio/webm';
      recordedBlob = new Blob(audioChunks, { type: type });
      recordedDuration = Math.max(1, Math.round((Date.now() - recordingStart) / 1000));
    };
    recordingStart = Date.now();
    try {
      mediaRecorder.start(250);
    } catch (e) {
      mediaRecorder.start();
    }
    voiceBtn.classList.add('recording');
    voiceBar.classList.remove('hidden');
    updateVoiceTimer();
    voiceTimerInterval = setInterval(updateVoiceTimer, 250);
  } catch (err) {
    console.error(err);
    alert('دسترسی به میکروفون ممکن نیست. در تنظیمات گوشی اجازه میکروفون را به اپ بدهید.');
  }
});

function updateVoiceTimer() {
  const sec = Math.floor((Date.now() - recordingStart) / 1000);
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  voiceTimerEl.textContent = toPersianNum(m) + ':' + toPersianNum(String(s).padStart(2, '0'));
  // حداکثر ۴۵ ثانیه
  if (sec >= 45 && mediaRecorder && mediaRecorder.state === 'recording') {
    stopRecording(true);
  }
}

function stopRecording(keep) {
  if (voiceTimerInterval) { clearInterval(voiceTimerInterval); voiceTimerInterval = null; }
  voiceBtn.classList.remove('recording');
  if (mediaRecorder && mediaRecorder.state === 'recording') {
    mediaRecorder.stop();
  }
  if (!keep) {
    voiceBar.classList.add('hidden');
    audioChunks = [];
    recordedBlob = null;
    mediaRecorder = null;
  } else {
    // کمی صبر تا onstop اجرا شود
    setTimeout(() => {
      voiceBar.classList.remove('hidden');
    }, 100);
  }
}

cancelVoiceBtn.addEventListener('click', () => stopRecording(false));

sendVoiceBtn.addEventListener('click', async () => {
  if (mediaRecorder && mediaRecorder.state === 'recording') {
    stopRecording(true);
    // صبر برای ساخته شدن blob
    await new Promise(r => setTimeout(r, 300));
  }
  if (!recordedBlob || recordedBlob.size < 100) {
    alert('ویس خیلی کوتاه است. دوباره ضبط کنید.');
    stopRecording(false);
    return;
  }
  if (recordedDuration > 45) {
    alert('حداکثر مدت ویس ۴۵ ثانیه است.');
    stopRecording(false);
    return;
  }

  sendVoiceBtn.disabled = true;
  sendVoiceBtn.textContent = 'در حال ارسال...';
  try {
    if (recordedBlob.size > 600 * 1024) {
      throw new Error('ویس خیلی طولانی است. کوتاه‌تر ضبط کنید (حداکثر حدود ۴۵ ثانیه).');
    }
    const voiceUrl = await blobToDataUrl(recordedBlob);

    const message = {
      name: currentUser.fullName,
      userId: currentUser.id,
      voiceUrl,
      voiceDuration: recordedDuration,
      timestamp: firebase.database.ServerValue.TIMESTAMP,
      status: 'sent'
    };
    if (currentUser.avatar) message.avatar = currentUser.avatar;
    if (typeof adminIds !== 'undefined' && adminIds[currentUser.id]) message.isAdmin = true;
    if (currentUser.isAdmin) message.isAdmin = true;
    if (replyToMessage) {
      message.replyTo = {
        id: replyToMessage.id,
        name: replyToMessage.name,
        text: replyToMessage.text || '🎤 ویس'
      };
    }
    await currentMessagesRef.push(message);
    if (chatMode === 'private' && privatePartner) {
      privateRef.child(getPrivateChatId(currentUser.id, privatePartner.id)).child('meta').update({
        updatedAt: firebase.database.ServerValue.TIMESTAMP,
        lastMessage: '🎤 ویس'
      });
      updatePrivateInbox(privatePartner.id, privatePartner.name, privatePartner.avatar, '🎤 ویس', true);
    }
    stopRecording(false);
    cancelReply();
  } catch (err) {
    console.error(err);
    alert('خطا در ارسال ویس: ' + (err.message || 'اتصال را بررسی کنید'));
  } finally {
    sendVoiceBtn.disabled = false;
    sendVoiceBtn.textContent = 'ارسال ویس';
  }
});

let currentVoiceBtn = null;
let currentVoiceWrap = null;

function setVoiceBtnPlaying(btn, playing) {
  if (!btn) return;
  const playIcon = btn.querySelector('.icon-play');
  const pauseIcon = btn.querySelector('.icon-pause');
  if (playIcon && pauseIcon) {
    playIcon.classList.toggle('hidden', playing);
    pauseIcon.classList.toggle('hidden', !playing);
  } else {
    btn.innerHTML = playing
      ? '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>'
      : '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>';
  }
  btn.classList.toggle('playing', playing);
}

function resetVoiceUi(btn, wrap) {
  setVoiceBtnPlaying(btn, false);
  if (wrap) {
    const progress = wrap.querySelector('.voice-wave-progress');
    const cur = wrap.querySelector('.voice-cur');
    if (progress) progress.style.width = '0%';
    if (cur) cur.textContent = '۰:۰۰';
  }
}

function stopCurrentVoice(resetUi) {
  if (currentAudio) {
    try { currentAudio.pause(); } catch (e) {}
    try { currentAudio.src = ''; } catch (e) {}
    currentAudio = null;
  }
  if (resetUi && currentVoiceBtn) {
    resetVoiceUi(currentVoiceBtn, currentVoiceWrap);
  }
  currentVoiceBtn = null;
  currentVoiceWrap = null;
}

function playVoice(url, btn, wrap) {
  if (!url || !btn) return;

  // اگر همین ویس در حال پخش است → توقف
  if (currentAudio && currentVoiceBtn === btn) {
    if (!currentAudio.paused) {
      currentAudio.pause();
      setVoiceBtnPlaying(btn, false);
      return;
    }
    // ادامه از همان جا
    currentAudio.play().then(() => setVoiceBtnPlaying(btn, true)).catch(() => {
      alert('پخش ویس ممکن نیست.');
      stopCurrentVoice(true);
    });
    return;
  }

  // توقف ویس قبلی
  stopCurrentVoice(true);

  const progressEl = wrap ? wrap.querySelector('.voice-wave-progress') : null;
  const curEl = wrap ? wrap.querySelector('.voice-cur') : null;
  const totalEl = wrap ? wrap.querySelector('.voice-total') : null;
  const knownDur = wrap ? parseFloat(wrap.dataset.duration || '0') : 0;

  const audio = new Audio();
  audio.preload = 'auto';
  // data URL یا لینک معمولی
  audio.src = url;

  currentAudio = audio;
  currentVoiceBtn = btn;
  currentVoiceWrap = wrap;
  setVoiceBtnPlaying(btn, true);

  const updateTime = () => {
    const t = audio.currentTime || 0;
    const d = (audio.duration && isFinite(audio.duration)) ? audio.duration : knownDur;
    if (progressEl && d > 0) {
      progressEl.style.width = Math.min(100, (t / d) * 100) + '%';
    }
    if (curEl) curEl.textContent = formatDuration(Math.floor(t));
    if (totalEl && d > 0 && (!knownDur || totalEl.textContent === '۰:۰۰')) {
      totalEl.textContent = formatDuration(Math.floor(d));
    }
  };

  audio.ontimeupdate = updateTime;
  audio.onloadedmetadata = updateTime;

  audio.onended = () => {
    resetVoiceUi(btn, wrap);
    currentAudio = null;
    currentVoiceBtn = null;
    currentVoiceWrap = null;
  };

  audio.onerror = () => {
    console.error('voice play error', audio.error);
    alert('پخش ویس ممکن نیست. دوباره ضبط کنید.');
    stopCurrentVoice(true);
  };

  // کلیک روی نوار پیشرفت برای جابه‌جایی
  if (wrap) {
    const wave = wrap.querySelector('.voice-wave');
    if (wave && !wave.dataset.seekBound) {
      wave.dataset.seekBound = '1';
      wave.addEventListener('click', (e) => {
        e.stopPropagation();
        if (!currentAudio || currentVoiceWrap !== wrap) return;
        const rect = wave.getBoundingClientRect();
        const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
        // RTL: از راست
        const rtlRatio = document.dir === 'rtl' ? (1 - ratio) : ratio;
        const d = currentAudio.duration || knownDur;
        if (d > 0) {
          currentAudio.currentTime = rtlRatio * d;
          updateTime();
        }
      });
    }
  }

  const p = audio.play();
  if (p && p.catch) {
    p.catch((err) => {
      console.error(err);
      alert('پخش ویس ممکن نیست.');
      stopCurrentVoice(true);
    });
  }
}

function formatDuration(sec) {
  sec = Math.max(0, Math.floor(Number(sec) || 0));
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return toPersianNum(m) + ':' + toPersianNum(String(s).padStart(2, '0'));
}


function showActionModal({ title, desc, confirmText, danger, showInput, inputValue }) {
  return new Promise((resolve) => {
    modalResolve = resolve;
    actionModalTitle.textContent = title;
    if (desc) {
      actionModalDesc.textContent = '';
      String(desc).split('\n').forEach((line, i, arr) => {
        actionModalDesc.appendChild(document.createTextNode(line));
        if (i < arr.length - 1) actionModalDesc.appendChild(document.createElement('br'));
      });
      actionModalDesc.style.display = 'block';
    } else {
      actionModalDesc.textContent = '';
      actionModalDesc.style.display = 'none';
    }
    actionModalConfirm.textContent = confirmText || 'تأیید';
    actionModalConfirm.classList.toggle('danger', !!danger);
    if (showInput) {
      actionModalEditWrap.classList.remove('hidden');
      actionModalInput.value = inputValue || '';
      setTimeout(() => {
        actionModalInput.focus();
        actionModalInput.setSelectionRange(actionModalInput.value.length, actionModalInput.value.length);
      }, 50);
    } else {
      actionModalEditWrap.classList.add('hidden');
    }
    actionModal.classList.remove('hidden');
  });
}

function closeActionModal(result) {
  actionModal.classList.add('hidden');
  const r = modalResolve;
  modalResolve = null;
  if (r) r(result);
}

if (actionModalCancel) {
  actionModalCancel.addEventListener('click', () => closeActionModal(null));
}
if (actionModalBackdrop) {
  actionModalBackdrop.addEventListener('click', () => closeActionModal(null));
}
if (actionModalConfirm) {
  actionModalConfirm.addEventListener('click', () => {
    if (!actionModalEditWrap.classList.contains('hidden')) {
      closeActionModal(actionModalInput.value);
    } else {
      closeActionModal(true);
    }
  });
}

function messagePreviewText(msg) {
  if (!msg) return '';
  if (msg.text && msg.text.trim()) {
    const t = msg.text.trim();
    return t.length > 80 ? t.slice(0, 80) + '…' : t;
  }
  if (msg.imageUrl || msg.imageBase64) return '📷 عکس';
  if (msg.voiceUrl) return '🎤 ویس';
  return 'این پیام';
}

async function editMessage(id, msg) {
  if (!msg || msg.userId !== currentUser.id) return;
  if (msg.voiceUrl && !msg.text && !(msg.imageUrl || msg.imageBase64)) {
    await showActionModal({
      title: 'قابل ویرایش نیست',
      desc: '«' + messagePreviewText(msg) + '» را نمی‌توان ویرایش کرد. در صورت نیاز حذفش کن.',
      confirmText: 'متوجه شدم',
      danger: false
    });
    return;
  }
  const currentText = msg.text || '';
  const preview = messagePreviewText(msg);
  const next = await showActionModal({
    title: 'ویرایش پیام',
    desc: 'این زری که زدی رو ویرایش می‌کنی؟\n«' + preview + '»',
    confirmText: 'ذخیره',
    showInput: true,
    inputValue: currentText
  });
  if (next === null) return;
  const trimmed = String(next).trim();
  if (!trimmed) {
    await showActionModal({
      title: 'متن خالی',
      desc: 'متن پیام نمی‌تواند خالی باشد. برای پاک کردن از حذف استفاده کن.',
      confirmText: 'باشه'
    });
    return;
  }
  if (trimmed === currentText) return;
  try {
    await currentMessagesRef.child(id).update({
      text: trimmed,
      edited: true,
      editedAt: firebase.database.ServerValue.TIMESTAMP
    });
  } catch (err) {
    console.error(err);
    await showActionModal({ title: 'خطا', desc: 'ویرایش پیام انجام نشد.', confirmText: 'باشه', danger: true });
  }
}

async function deleteMessage(id, msg) {
  const preview = messagePreviewText(msg);
  const ok = await showActionModal({
    title: 'حذف پیام',
    desc: 'این زری که زدی رو حذف می‌کنی؟\n«' + preview + '»',
    confirmText: 'حذف کن',
    danger: true
  });
  if (!ok) return;
  try {
    await currentMessagesRef.child(id).remove();
  } catch (err) {
    console.error(err);
    await showActionModal({ title: 'خطا', desc: 'حذف پیام انجام نشد.', confirmText: 'باشه', danger: true });
  }
}

// ===== Reply =====
function setReplyTo(msg) {
  replyToMessage = msg;
  replyToNameEl.textContent = msg.name;
  const shortText = (msg.text || '').length > 40 ? msg.text.slice(0, 40) + '…' : (msg.text || '');
  replyToTextEl.textContent = shortText;
  replyBar.classList.remove('hidden');
  messageInput.focus();
}
function cancelReply() {
  replyToMessage = null;
  replyBar.classList.add('hidden');
  replyToNameEl.textContent = '';
  replyToTextEl.textContent = '';
}
cancelReplyBtn.addEventListener('click', cancelReply);

// ===== Send text/image =====
messageForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const text = messageInput.value.trim();
  if ((!text && !pendingImageFile) || !currentUser) return;
  sendBtn.disabled = true;
  attachBtn.disabled = true;
  try {
    let imageUrl = null;
    if (pendingImageFile) {
      try {
        imageUrl = await uploadImageWithProgress(pendingImageFile);
      } finally {
        hideUploadProgress();
      }
    }
    const message = {
      name: currentUser.fullName,
      userId: currentUser.id,
      timestamp: firebase.database.ServerValue.TIMESTAMP
    };
    if (currentUser.avatar) message.avatar = currentUser.avatar;
    if (currentUser.isAdmin) message.isAdmin = true;
    if (text) message.text = text;
    if (imageUrl) message.imageUrl = imageUrl;
    if (replyToMessage) {
      message.replyTo = {
        id: replyToMessage.id,
        name: replyToMessage.name,
        text: (replyToMessage.text || '').length > 80 ? replyToMessage.text.slice(0, 80) + '…' : (replyToMessage.text || '')
      };
    }
    await currentMessagesRef.push(message);
    if (chatMode === 'private' && privatePartner) {
      const last = text || (imageUrl ? '📷 عکس' : '');
      privateRef.child(getPrivateChatId(currentUser.id, privatePartner.id)).child('meta').update({
        updatedAt: firebase.database.ServerValue.TIMESTAMP,
        lastMessage: last
      });
      updatePrivateInbox(privatePartner.id, privatePartner.name, privatePartner.avatar, last, true);
    }
    messageInput.value = '';
    clearPendingImage();
    cancelReply();
    messageInput.focus();
  } catch (err) {
    console.error(err);
    alert('خطا در ارسال: ' + (err.message || 'اتصال یا حجم فایل را بررسی کنید'));
  } finally {
    sendBtn.disabled = messageInput.value.trim().length === 0 && !pendingImageFile;
    attachBtn.disabled = false;
  }
});

messageInput.addEventListener('input', () => {
  sendBtn.disabled = messageInput.value.trim().length === 0 && !pendingImageFile;
});

function scrollToBottom() {
  requestAnimationFrame(() => { messagesContainer.scrollTop = messagesContainer.scrollHeight; });
}
function formatTime(timestamp) {
  if (!timestamp) return '';
  const date = new Date(timestamp);
  const isToday = date.toDateString() === new Date().toDateString();
  const h = date.getHours().toString().padStart(2, '0');
  const m = date.getMinutes().toString().padStart(2, '0');
  return isToday ? `${h}:${m}` : `${date.getDate()}/${date.getMonth() + 1} ${h}:${m}`;
}

function tickSvg(doubleTick) {
  if (doubleTick) {
    return `<svg viewBox="0 0 16 11" fill="none"><path d="M1.5 6 L4 8.5 L9 2.5" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/><path d="M5.5 6.5 L8 9 L14.5 2" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
  }
  return `<svg viewBox="0 0 12 11" fill="none"><path d="M1.5 6 L4.5 9 L10.5 2" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
}

function statusTicksHtml(status) {
  const s = status || 'sent';
  if (s === 'read') return `<span class="msg-ticks read" title="خوانده شد">${tickSvg(true)}</span>`;
  if (s === 'delivered') return `<span class="msg-ticks delivered" title="رسیده">${tickSvg(true)}</span>`;
  return `<span class="msg-ticks sent" title="ارسال شد">${tickSvg(false)}</span>`;
}

function updateMessageTicks(el, status) {
  if (!el) return;
  let wrap = el.querySelector('.msg-ticks');
  if (!wrap) return;
  const html = statusTicksHtml(status);
  wrap.outerHTML = html;
}

/** گیرنده: تحویل / خوانده شدن پیام‌های دیگران را ثبت می‌کند */
function acknowledgeMessage(ref, id, msg, asRead) {
  if (!msg || !currentUser || msg.userId === currentUser.id) return;
  const st = msg.status || 'sent';
  if (asRead) {
    if (st === 'read') return;
    ref.child(id).update({ status: 'read', readAt: firebase.database.ServerValue.TIMESTAMP }).catch(() => {});
  } else {
    if (st === 'delivered' || st === 'read') return;
    ref.child(id).update({ status: 'delivered', deliveredAt: firebase.database.ServerValue.TIMESTAMP }).catch(() => {});
  }
}

function markVisibleMessagesRead() {
  if (!currentMessagesRef || !currentUser) return;
  document.querySelectorAll('.message.other').forEach((el) => {
    const id = el.dataset.id;
    if (!id) return;
    // فقط ارتقا به read — delivered قبلاً زده شده
    currentMessagesRef.child(id).once('value', (snap) => {
      const msg = snap.val();
      if (msg) acknowledgeMessage(currentMessagesRef, id, msg, true);
    });
  });
}

function escapeHtml(text) {
  if (!text) return '';
  const d = document.createElement('div');
  d.textContent = text;
  return d.innerHTML;
}
messageInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    if (!sendBtn.disabled) messageForm.dispatchEvent(new Event('submit'));
  }
});

function onNewMessageNotification(msg) {
  if (msg.userId === currentUser.id) return;
  unreadCount++;
  const title = msg.name || 'پیام جدید';
  let body = msg.text || '';
  if (!body && msg.imageUrl) body = 'یک عکس ارسال شد';
  if (!body && msg.voiceUrl) body = 'یک ویس ارسال شد';
  if (!body) body = 'پیام جدید';
  if (window.AndroidBridge && window.AndroidBridge.showNotification) {
    try { window.AndroidBridge.showNotification(title, body, unreadCount); } catch (e) {}
  }
  if ('Notification' in window && Notification.permission === 'granted' && !appInForeground) {
    try { new Notification(title, { body, tag: 'chat-msg', renotify: true }); } catch (e) {}
  }
}
function clearUnreadBadge() {
  unreadCount = 0;
  if (window.AndroidBridge && window.AndroidBridge.clearNotifications) {
    try { window.AndroidBridge.clearNotifications(); } catch (e) {}
  }
}
if ('Notification' in window && Notification.permission === 'default') {
  Notification.requestPermission().catch(() => {});
}
document.addEventListener('visibilitychange', () => {
  appInForeground = document.visibilityState === 'visible';
  if (appInForeground) markVisibleMessagesRead();
  if (appInForeground && chatMode === 'public') clearUnreadBadge();
  if (appInForeground && currentUser && myPresenceRef) {
    myPresenceRef.set({ name: currentUser.fullName, lastSeen: firebase.database.ServerValue.TIMESTAMP });
  }
});
window.addEventListener('beforeunload', stopPresence);

messagesRef.limitToLast(1).on('child_added', (snap) => {
  if (isInitialLoad) return;
  const msg = snap.val();
  if (!msg || !currentUser || msg.userId === currentUser.id) return;
  if (chatMode === 'public' && appInForeground) return;
  if (snap.key === lastKnownMessageKey) return;
  onNewMessageNotification(msg);
});
