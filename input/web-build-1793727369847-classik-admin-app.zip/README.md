# Classik Admin — اپ پنل مدیریت

اپ جدا از چت. در AndroidForge آپلود و بیلد کن.

رمز ورود پیش‌فرض: classik2026
(در app/src/main/assets/www/admin.js قابل تغییر)
