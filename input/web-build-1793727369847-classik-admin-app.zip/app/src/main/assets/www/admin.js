// ====== تنظیمات — با اپ چت یکی باشد ======
const firebaseConfig = {
  apiKey: "AIzaSyBWkd5Zi_1Pb9zThRGun69VcOwYaNyDckw",
  authDomain: "sample-firebase-ai-app-f211a.firebaseapp.com",
  databaseURL: "https://sample-firebase-ai-app-f211a-default-rtdb.firebaseio.com",
  projectId: "sample-firebase-ai-app-f211a",
  storageBucket: "sample-firebase-ai-app-f211a.firebasestorage.app",
  messagingSenderId: "689511797055",
  appId: "1:689511797055:web:5269152f011d284962438a"
};

// رمز پنل ادمین را اینجا عوض کنید
const ADMIN_PASSWORD = "classik2026";

firebase.initializeApp(firebaseConfig);
const db = firebase.database();
const messagesRef = db.ref('messages');
const adminsRef = db.ref('admins');

const loginView = document.getElementById('login-view');
const panelView = document.getElementById('panel-view');
const adminPass = document.getElementById('admin-pass');
const loginBtn = document.getElementById('login-btn');
const loginError = document.getElementById('login-error');
const logoutBtn = document.getElementById('logout-btn');
const msgList = document.getElementById('msg-list');
const statCount = document.getElementById('stat-count');
const statSize = document.getElementById('stat-size');
const filterType = document.getElementById('filter-type');
const searchMsg = document.getElementById('search-msg');
const cleanupResult = document.getElementById('cleanup-result');
const adminListEl = document.getElementById('admin-list');

let allMessages = []; // { id, ...data }

if (sessionStorage.getItem('classikAdmin') === '1') {
  showPanel();
}

loginBtn.addEventListener('click', tryLogin);
adminPass.addEventListener('keydown', (e) => { if (e.key === 'Enter') tryLogin(); });

function tryLogin() {
  if (adminPass.value === ADMIN_PASSWORD) {
    sessionStorage.setItem('classikAdmin', '1');
    loginError.classList.add('hidden');
    showPanel();
  } else {
    loginError.classList.remove('hidden');
  }
}

logoutBtn.addEventListener('click', () => {
  sessionStorage.removeItem('classikAdmin');
  panelView.classList.remove('active');
  loginView.classList.add('active');
  adminPass.value = '';
});

function showPanel() {
  loginView.classList.remove('active');
  panelView.classList.add('active');
  loadMessages();
  loadAdmins();
}

// Tabs
document.querySelectorAll('.tab').forEach((tab) => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((t) => t.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach((p) => p.classList.remove('active'));
    tab.classList.add('active');
    const panel = document.getElementById('tab-' + tab.dataset.tab);
    if (panel) panel.classList.add('active');
    if (tab.dataset.tab === 'chat' && typeof startAdminLiveChat === 'function') {
      setTimeout(startAdminLiveChat, 30);
    }
  });
});

function toPersianNum(n) {
  const p = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
  return String(n).replace(/\d/g, (d) => p[d]);
}

function formatTime(ts) {
  if (!ts) return '—';
  const d = new Date(ts);
  return d.toLocaleString('fa-IR');
}

function approxSize(obj) {
  try {
    return new Blob([JSON.stringify(obj)]).size;
  } catch {
    return JSON.stringify(obj).length;
  }
}

function formatBytes(b) {
  if (b < 1024) return b + ' B';
  if (b < 1024 * 1024) return (b / 1024).toFixed(1) + ' KB';
  return (b / (1024 * 1024)).toFixed(2) + ' MB';
}

function loadMessages() {
  msgList.innerHTML = '<p class="hint">در حال بارگذاری...</p>';
  messagesRef.once('value', (snap) => {
    allMessages = [];
    let totalSize = 0;
    if (snap.exists()) {
      snap.forEach((c) => {
        const val = c.val() || {};
        allMessages.push({ id: c.key, ...val });
        totalSize += approxSize(val);
      });
    }
    allMessages.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
    statCount.textContent = toPersianNum(allMessages.length) + ' پیام';
    statSize.textContent = 'حجم تقریبی: ' + formatBytes(totalSize);
    renderMessages();
  }, (err) => {
    msgList.innerHTML = '<p class="error">خطا در اتصال به دیتابیس</p>';
    console.error(err);
  });
}

document.getElementById('refresh-msg').addEventListener('click', loadMessages);
filterType.addEventListener('change', renderMessages);
searchMsg.addEventListener('input', renderMessages);

function renderMessages() {
  const type = filterType.value;
  const q = (searchMsg.value || '').trim().toLowerCase();
  let list = allMessages.filter((m) => {
    if (type === 'text' && (m.imageUrl || m.imageBase64 || m.voiceUrl)) return false;
    if (type === 'image' && !(m.imageUrl || m.imageBase64)) return false;
    if (type === 'voice' && !m.voiceUrl) return false;
    if (q) {
      const hay = ((m.text || '') + ' ' + (m.name || '') + ' ' + (m.userId || '')).toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });

  if (!list.length) {
    msgList.innerHTML = '<p class="hint">پیامی یافت نشد.</p>';
    return;
  }

  msgList.innerHTML = list.map((m) => {
    const tags = [];
    if (m.imageUrl || m.imageBase64) tags.push('<span class="tag image">عکس</span>');
    if (m.voiceUrl) tags.push('<span class="tag voice">ویس</span>');
    if (m.isAdmin) tags.push('<span class="tag">مدیر</span>');
    if (m.edited) tags.push('<span class="tag">ویرایش‌شده</span>');

    let body = '';
    if (m.text) body += `<div>${escapeHtml(m.text)}</div>`;
    const img = m.imageUrl || m.imageBase64;
    if (img) body += `<img src="${escapeAttr(img)}" class="preview-img" alt="عکس">`;
    if (m.voiceUrl) {
      body += `<div class="audio-row"><audio controls preload="none" src="${escapeAttr(m.voiceUrl)}"></audio></div>`;
    }
    if (!body) body = '<div class="hint">بدون محتوا</div>';

    return `<div class="msg-item" data-id="${escapeAttr(m.id)}">
      <div class="msg-head">
        <span class="name">${escapeHtml(m.name || '—')}</span>
        ${tags.join('')}
        <span>${formatTime(m.timestamp)}</span>
        <span class="uid" title="کپی userId" data-uid="${escapeAttr(m.userId || '')}">${escapeHtml(m.userId || '—')}</span>
      </div>
      <div class="msg-body">${body}</div>
      <div class="msg-actions">
        <button type="button" class="del" data-del="${escapeAttr(m.id)}">حذف</button>
      </div>
    </div>`;
  }).join('');

  msgList.querySelectorAll('.uid').forEach((el) => {
    el.addEventListener('click', () => {
      const u = el.dataset.uid;
      if (u && navigator.clipboard) navigator.clipboard.writeText(u);
      el.textContent = 'کپی شد!';
      setTimeout(() => { el.textContent = u; }, 1000);
    });
  });
  msgList.querySelectorAll('[data-del]').forEach((btn) => {
    btn.addEventListener('click', () => deleteOne(btn.dataset.del));
  });
  msgList.querySelectorAll('.preview-img').forEach((img) => {
    img.addEventListener('click', () => {
      document.getElementById('lb-img').src = img.src;
      document.getElementById('preview-lightbox').classList.remove('hidden');
    });
  });
}

document.getElementById('lb-close').addEventListener('click', () => {
  document.getElementById('preview-lightbox').classList.add('hidden');
});

function escapeHtml(s) {
  const d = document.createElement('div');
  d.textContent = s || '';
  return d.innerHTML;
}
function escapeAttr(s) {
  return String(s || '').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;');
}

async function deleteOne(id) {
  if (!confirm('این پیام حذف شود؟')) return;
  await messagesRef.child(id).remove();
  allMessages = allMessages.filter((m) => m.id !== id);
  statCount.textContent = toPersianNum(allMessages.length) + ' پیام';
  renderMessages();
}

// Cleanup
function rangeBounds(range) {
  const now = Date.now();
  const day = 24 * 60 * 60 * 1000;
  if (range === 'day') return { from: now - day, to: now };
  if (range === 'week') return { from: now - 7 * day, to: now };
  if (range === 'month') return { from: now - 30 * day, to: now };
  if (range === 'all') return { from: 0, to: Infinity };
  return null;
}

async function cleanupByRange(from, to) {
  cleanupResult.textContent = 'در حال حذف...';
  const snap = await messagesRef.once('value');
  const updates = {};
  let count = 0;
  snap.forEach((c) => {
    const ts = (c.val() && c.val().timestamp) || 0;
    if (ts >= from && ts <= to) {
      updates[c.key] = null;
      count++;
    }
  });
  if (count === 0) {
    cleanupResult.textContent = 'پیامی در این بازه نبود.';
    return;
  }
  if (!confirm(count + ' پیام حذف شود؟ این کار برگشت‌ناپذیر است.')) {
    cleanupResult.textContent = 'لغو شد.';
    return;
  }
  await messagesRef.update(updates);
  cleanupResult.textContent = count + ' پیام حذف شد. دیتابیس سبک‌تر شد.';
  loadMessages();
}

document.querySelectorAll('.cleanup-btn').forEach((btn) => {
  btn.addEventListener('click', () => {
    const b = rangeBounds(btn.dataset.range);
    if (b) cleanupByRange(b.from, b.to);
  });
});

document.getElementById('cleanup-custom').addEventListener('click', () => {
  const fromEl = document.getElementById('from-date').value;
  const toEl = document.getElementById('to-date').value;
  if (!fromEl || !toEl) {
    cleanupResult.textContent = 'هر دو تاریخ را انتخاب کنید.';
    return;
  }
  const from = new Date(fromEl).setHours(0, 0, 0, 0);
  const to = new Date(toEl).setHours(23, 59, 59, 999);
  cleanupByRange(from, to);
});

// Admins
function loadAdmins() {
  adminsRef.on('value', (snap) => {
    const items = [];
    if (snap.exists()) {
      snap.forEach((c) => {
        const v = c.val();
        items.push({ id: c.key, name: (v && v.name) || '' });
      });
    }
    if (!items.length) {
      adminListEl.innerHTML = '<p class="hint">مدیری ثبت نشده.</p>';
      return;
    }
    adminListEl.innerHTML = items.map((a) => `
      <div class="admin-item">
        <div>
          <strong>${escapeHtml(a.name || 'مدیر')}</strong>
          <div class="uid">${escapeHtml(a.id)}</div>
        </div>
        <button type="button" data-rm="${escapeAttr(a.id)}">حذف</button>
      </div>
    `).join('');
    adminListEl.querySelectorAll('[data-rm]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        if (!confirm('این مدیر حذف شود؟')) return;
        await adminsRef.child(btn.dataset.rm).remove();
      });
    });
  });
}

document.getElementById('add-admin').addEventListener('click', async () => {
  const id = document.getElementById('admin-userid').value.trim();
  const name = document.getElementById('admin-name').value.trim();
  if (!id) return alert('userId لازم است');
  await adminsRef.child(id).set({ name: name || 'مدیر', addedAt: Date.now() });
  document.getElementById('admin-userid').value = '';
  document.getElementById('admin-name').value = '';
});



// ===== چت زنده ادمین — کامل مثل اپ =====
const alcMessages = document.getElementById('alc-messages');
const alcForm = document.getElementById('alc-form');
const alcInput = document.getElementById('alc-input');
let alcListener = null;
let alcChangedListener = null;
let alcRemovedListener = null;
let alcReplyTo = null;
let alcPendingImage = null;
let alcMediaRecorder = null;
let alcAudioChunks = [];
let alcRecordedBlob = null;
let alcRecordedDuration = 0;
let alcRecordingStart = 0;
let alcVoiceTimer = null;
let alcCurrentAudio = null;
let alcActionResolve = null;

function getAdminId() {
  return ((document.getElementById('admin-chat-id') || {}).value || '').trim() || 'admin_classik';
}
function getAdminName() {
  return ((document.getElementById('admin-chat-name') || {}).value || '').trim() || 'مدیر Classik';
}
function getAdminAvatar() {
  try {
    return localStorage.getItem('adminAvatar_' + getAdminId()) || null;
  } catch (e) { return null; }
}
function setAdminAvatar(dataUrl) {
  try {
    if (dataUrl) localStorage.setItem('adminAvatar_' + getAdminId(), dataUrl);
    else localStorage.removeItem('adminAvatar_' + getAdminId());
  } catch (e) {}
  updateAlcAvatarUI();
  db.ref('users/' + getAdminId()).update({
    name: getAdminName(),
    avatar: dataUrl || null,
    isAdmin: true,
    updatedAt: firebase.database.ServerValue.TIMESTAMP
  }).catch(() => {});
}
function updateAlcAvatarUI() {
  const av = getAdminAvatar();
  ['alc-header-av', 'alc-modal-av'].forEach((id) => {
    const el = document.getElementById(id);
    if (!el) return;
    if (av) { el.src = av; el.classList.remove('hidden'); }
    else { el.src = ''; el.classList.add('hidden'); }
  });
  ['alc-header-av-fb', 'alc-modal-av-fb'].forEach((id) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.classList.toggle('hidden', !!av);
  });
}

function alcEscape(s) {
  const d = document.createElement('div');
  d.textContent = s || '';
  return d.innerHTML;
}
function alcTime(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  return d.getHours().toString().padStart(2, '0') + ':' + d.getMinutes().toString().padStart(2, '0');
}
function alcPersian(n) {
  const p = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
  return String(n).replace(/\d/g, d => p[d]);
}
function alcFormatDur(sec) {
  sec = Math.max(0, Math.floor(Number(sec) || 0));
  return alcPersian(Math.floor(sec / 60)) + ':' + alcPersian(String(sec % 60).padStart(2, '0'));
}

function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = reject;
    r.readAsDataURL(blob);
  });
}
function compressImage(file, maxWidth, quality) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      URL.revokeObjectURL(url);
      let w = img.width, h = img.height;
      if (w > maxWidth) { h = Math.round(h * maxWidth / w); w = maxWidth; }
      const c = document.createElement('canvas');
      c.width = w; c.height = h;
      c.getContext('2d').drawImage(img, 0, 0, w, h);
      c.toBlob(b => b ? resolve(b) : reject(new Error('compress fail')), 'image/jpeg', quality);
    };
    img.onerror = reject;
    img.src = url;
  });
}

function showAlcAction({ title, desc, confirmText, danger, showInput, inputValue }) {
  return new Promise((resolve) => {
    alcActionResolve = resolve;
    const modal = document.getElementById('alc-action-modal');
    document.getElementById('alc-action-title').textContent = title;
    document.getElementById('alc-action-desc').textContent = desc || '';
    const ok = document.getElementById('alc-action-ok');
    ok.textContent = confirmText || 'تأیید';
    ok.className = danger ? 'alc-btn-danger' : 'alc-btn-gold';
    const wrap = document.getElementById('alc-action-edit-wrap');
    if (showInput) {
      wrap.classList.remove('hidden');
      document.getElementById('alc-action-input').value = inputValue || '';
    } else wrap.classList.add('hidden');
    modal.classList.remove('hidden');
  });
}
function closeAlcAction(val) {
  document.getElementById('alc-action-modal').classList.add('hidden');
  const r = alcActionResolve;
  alcActionResolve = null;
  if (r) r(val);
}
document.getElementById('alc-action-cancel')?.addEventListener('click', () => closeAlcAction(null));
document.getElementById('alc-action-bg')?.addEventListener('click', () => closeAlcAction(null));
document.getElementById('alc-action-ok')?.addEventListener('click', () => {
  const wrap = document.getElementById('alc-action-edit-wrap');
  if (!wrap.classList.contains('hidden')) closeAlcAction(document.getElementById('alc-action-input').value);
  else closeAlcAction(true);
});

function alcAppend(msg, id) {
  if (!alcMessages || !msg) return;
  if (document.querySelector('.alc-msg[data-id="' + id + '"]')) return;
  const empty = alcMessages.querySelector('.alc-empty');
  if (empty) empty.remove();

  const adminId = getAdminId();
  const isMe = msg.userId === adminId;
  const isAdmin = !!(msg.isAdmin || msg.userId === adminId);
  const div = document.createElement('div');
  div.className = 'alc-msg ' + (isMe ? 'me' : 'other') + (isAdmin ? ' admin' : '');
  div.dataset.id = id;

  let body = '';
  if (msg.replyTo) {
    body += '<div class="alc-reply-quote"><b>' + alcEscape(msg.replyTo.name || '') + '</b><br>' + alcEscape(msg.replyTo.text || '') + '</div>';
  }
  if (msg.text) body += '<div>' + alcEscape(msg.text) + '</div>';
  const img = msg.imageUrl || msg.imageBase64;
  if (img) body += '<img src="' + alcEscape(img) + '" alt="" class="alc-msg-img">';
  if (msg.voiceUrl) {
    body += '<div class="voice-row" data-url="">' +
      '<button type="button" class="alc-play-v">▶</button>' +
      '<div class="voice-wave"><div class="voice-prog"></div></div>' +
      '<span class="alc-vdur">' + alcFormatDur(msg.voiceDuration || 0) + '</span></div>';
  }
  if (!body) body = '<div style="opacity:.6">—</div>';

  const badge = isAdmin ? '<span class="alc-badge">مدیر</span><span class="alc-tick">✓</span>' : '';
  const edited = msg.edited ? '<span class="alc-edited">ویرایش‌شده</span>' : '';
  let actions = '<div class="alc-actions"><button type="button" class="alc-reply-btn">پاسخ</button>';
  if (isMe) {
    actions += '<button type="button" class="alc-edit-btn">ویرایش</button>';
    actions += '<button type="button" class="alc-del-btn del">حذف</button>';
  }
  actions += '</div>';

  div.innerHTML =
    '<div class="alc-meta">' +
      '<span class="alc-name">' + alcEscape(msg.name || '—') + '</span>' + badge +
      '<span class="alc-time">' + alcTime(msg.timestamp) + '</span>' + edited +
    '</div>' +
    '<div class="alc-bubble">' + body + '</div>' + actions;

  div.querySelector('.alc-reply-btn')?.addEventListener('click', () => {
    let preview = msg.text || '';
    if (!preview && img) preview = '📷 عکس';
    if (!preview && msg.voiceUrl) preview = '🎤 ویس';
    alcReplyTo = { id, name: msg.name || '', text: preview };
    document.getElementById('alc-reply-preview').textContent = (msg.name || '') + ': ' + preview;
    document.getElementById('alc-reply-bar').classList.remove('hidden');
    alcInput.focus();
  });
  div.querySelector('.alc-edit-btn')?.addEventListener('click', async () => {
    if (!msg.text && (msg.voiceUrl || img)) {
      await showAlcAction({ title: 'قابل ویرایش نیست', desc: 'فقط پیام متنی ویرایش می‌شود.', confirmText: 'باشه' });
      return;
    }
    const next = await showAlcAction({
      title: 'ویرایش پیام',
      desc: 'متن جدید را بنویسید',
      confirmText: 'ذخیره',
      showInput: true,
      inputValue: msg.text || ''
    });
    if (next === null) return;
    const trimmed = String(next).trim();
    if (!trimmed) return;
    await messagesRef.child(id).update({
      text: trimmed,
      edited: true,
      editedAt: firebase.database.ServerValue.TIMESTAMP
    });
  });
  div.querySelector('.alc-del-btn')?.addEventListener('click', async () => {
    const ok = await showAlcAction({
      title: 'حذف پیام',
      desc: 'این پیام حذف شود؟',
      confirmText: 'حذف کن',
      danger: true
    });
    if (!ok) return;
    await messagesRef.child(id).remove();
  });
  const playBtn = div.querySelector('.alc-play-v');
  if (playBtn && msg.voiceUrl) {
    playBtn.addEventListener('click', () => {
      const prog = div.querySelector('.voice-prog');
      if (alcCurrentAudio && alcCurrentAudio._btn === playBtn) {
        if (!alcCurrentAudio.paused) { alcCurrentAudio.pause(); playBtn.textContent = '▶'; return; }
        alcCurrentAudio.play(); playBtn.textContent = '❚❚'; return;
      }
      if (alcCurrentAudio) { try { alcCurrentAudio.pause(); } catch(e) {} }
      const a = new Audio(msg.voiceUrl);
      a._btn = playBtn;
      alcCurrentAudio = a;
      playBtn.textContent = '❚❚';
      a.ontimeupdate = () => {
        if (prog && a.duration) prog.style.width = ((a.currentTime / a.duration) * 100) + '%';
      };
      a.onended = () => { playBtn.textContent = '▶'; if (prog) prog.style.width = '0%'; };
      a.onerror = () => { playBtn.textContent = '▶'; alert('پخش ویس ممکن نیست'); };
      a.play().catch(() => alert('پخش ویس ممکن نیست'));
    });
  }
  div.querySelector('.alc-msg-img')?.addEventListener('click', () => {
    document.getElementById('lb-img').src = img;
    document.getElementById('preview-lightbox').classList.remove('hidden');
  });

  alcMessages.appendChild(div);
  alcMessages.scrollTop = alcMessages.scrollHeight;
}

function detachAlcListeners() {
  if (alcListener) messagesRef.off('child_added', alcListener);
  if (alcChangedListener) messagesRef.off('child_changed', alcChangedListener);
  if (alcRemovedListener) messagesRef.off('child_removed', alcRemovedListener);
  alcListener = alcChangedListener = alcRemovedListener = null;
}

function startAdminLiveChat() {
  if (!alcMessages) return;
  detachAlcListeners();
  updateAlcAvatarUI();
  alcMessages.innerHTML = '<div class="alc-empty">در حال بارگذاری گفتگو...</div>';
  messagesRef.limitToLast(100).once('value', (snap) => {
    alcMessages.innerHTML = '';
    if (!snap.exists()) {
      alcMessages.innerHTML = '<div class="alc-empty">هنوز پیامی نیست. اولین پیام مدیر را بفرستید 👑</div>';
    } else {
      snap.forEach((c) => alcAppend(c.val(), c.key));
      alcMessages.scrollTop = alcMessages.scrollHeight;
    }
    alcListener = messagesRef.limitToLast(100).on('child_added', (s) => {
      if (document.querySelector('.alc-msg[data-id="' + s.key + '"]')) return;
      alcAppend(s.val(), s.key);
    });
    alcChangedListener = messagesRef.on('child_changed', (s) => {
      const el = document.querySelector('.alc-msg[data-id="' + s.key + '"]');
      if (el) el.remove();
      alcAppend(s.val(), s.key);
    });
    alcRemovedListener = messagesRef.on('child_removed', (s) => {
      const el = document.querySelector('.alc-msg[data-id="' + s.key + '"]');
      if (el) el.remove();
    });
  }, () => {
    alcMessages.innerHTML = '<div class="alc-empty">خطا در اتصال به دیتابیس</div>';
  });
}

async function alcBuildMessage(extra) {
  const message = Object.assign({
    name: getAdminName(),
    userId: getAdminId(),
    isAdmin: true,
    status: 'sent',
    timestamp: firebase.database.ServerValue.TIMESTAMP
  }, extra || {});
  const av = getAdminAvatar();
  if (av) message.avatar = av;
  if (alcReplyTo) {
    message.replyTo = { id: alcReplyTo.id, name: alcReplyTo.name, text: alcReplyTo.text };
  }
  return message;
}

function alcClearReply() {
  alcReplyTo = null;
  document.getElementById('alc-reply-bar')?.classList.add('hidden');
}
document.getElementById('alc-reply-cancel')?.addEventListener('click', alcClearReply);

// تصویر
document.getElementById('alc-attach')?.addEventListener('click', () => {
  const f = document.getElementById('alc-file');
  if (f) { f.value = ''; f.click(); }
});
document.getElementById('alc-file')?.addEventListener('change', () => {
  const file = document.getElementById('alc-file').files?.[0];
  if (!file || !file.type.startsWith('image/')) return;
  alcPendingImage = file;
  const reader = new FileReader();
  reader.onload = (e) => {
    document.getElementById('alc-img-thumb').src = e.target.result;
    document.getElementById('alc-img-name').textContent = file.name || 'عکس';
    document.getElementById('alc-img-bar').classList.remove('hidden');
  };
  reader.readAsDataURL(file);
});
document.getElementById('alc-img-cancel')?.addEventListener('click', () => {
  alcPendingImage = null;
  document.getElementById('alc-img-bar').classList.add('hidden');
});

function setAlcUp(p) {
  const wrap = document.getElementById('alc-up-wrap');
  const bar = document.getElementById('alc-up-bar');
  const txt = document.getElementById('alc-up-txt');
  wrap?.classList.remove('hidden');
  txt?.classList.remove('hidden');
  if (bar) bar.style.width = p + '%';
  if (txt) txt.textContent = alcPersian(p) + '٪';
}

// ویس
document.getElementById('alc-mic')?.addEventListener('click', async () => {
  if (alcMediaRecorder && alcMediaRecorder.state === 'recording') return;
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    alcAudioChunks = [];
    let mime = '';
    for (const c of ['audio/mp4', 'audio/webm;codecs=opus', 'audio/webm', 'audio/ogg']) {
      if (MediaRecorder.isTypeSupported(c)) { mime = c; break; }
    }
    alcMediaRecorder = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream);
    alcMediaRecorder.ondataavailable = (e) => { if (e.data?.size) alcAudioChunks.push(e.data); };
    alcMediaRecorder.onstop = () => {
      stream.getTracks().forEach(t => t.stop());
      alcRecordedBlob = new Blob(alcAudioChunks, { type: alcMediaRecorder.mimeType || 'audio/webm' });
      alcRecordedDuration = Math.max(1, Math.round((Date.now() - alcRecordingStart) / 1000));
    };
    alcRecordingStart = Date.now();
    alcMediaRecorder.start(250);
    document.getElementById('alc-mic')?.classList.add('recording');
    document.getElementById('alc-voice-bar')?.classList.remove('hidden');
    alcVoiceTimer = setInterval(() => {
      const sec = Math.floor((Date.now() - alcRecordingStart) / 1000);
      document.getElementById('alc-voice-timer').textContent = alcFormatDur(sec);
      if (sec >= 45) stopAlcRec(true);
    }, 250);
  } catch (e) {
    alert('دسترسی میکروفون ممکن نیست.');
  }
});
function stopAlcRec(keep) {
  if (alcVoiceTimer) { clearInterval(alcVoiceTimer); alcVoiceTimer = null; }
  document.getElementById('alc-mic')?.classList.remove('recording');
  if (alcMediaRecorder && alcMediaRecorder.state === 'recording') alcMediaRecorder.stop();
  if (!keep) {
    document.getElementById('alc-voice-bar')?.classList.add('hidden');
    alcRecordedBlob = null;
  }
}
document.getElementById('alc-voice-cancel')?.addEventListener('click', () => stopAlcRec(false));
document.getElementById('alc-voice-send')?.addEventListener('click', async () => {
  if (alcMediaRecorder?.state === 'recording') {
    stopAlcRec(true);
    await new Promise(r => setTimeout(r, 350));
  }
  if (!alcRecordedBlob || alcRecordedBlob.size < 100) {
    alert('ویس خیلی کوتاه است');
    stopAlcRec(false);
    return;
  }
  try {
    const voiceUrl = await blobToDataUrl(alcRecordedBlob);
    const message = await alcBuildMessage({
      voiceUrl,
      voiceDuration: alcRecordedDuration
    });
    await messagesRef.push(message);
    await adminsRef.child(getAdminId()).set({ name: getAdminName(), addedAt: Date.now() });
    stopAlcRec(false);
    alcClearReply();
  } catch (e) {
    alert('خطا در ارسال ویس');
  }
});

// ارسال متن/عکس
if (alcForm) {
  alcForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const text = (alcInput.value || '').trim();
    if (!text && !alcPendingImage) return;
    const btn = document.getElementById('alc-send');
    if (btn) btn.disabled = true;
    try {
      let imageUrl = null;
      if (alcPendingImage) {
        setAlcUp(15);
        let blob = await compressImage(alcPendingImage, 900, 0.55);
        setAlcUp(55);
        if (blob.size > 450 * 1024) blob = await compressImage(alcPendingImage, 700, 0.4);
        setAlcUp(85);
        imageUrl = await blobToDataUrl(blob);
        setAlcUp(100);
      }
      const extra = {};
      if (text) extra.text = text;
      if (imageUrl) extra.imageUrl = imageUrl;
      const message = await alcBuildMessage(extra);
      await messagesRef.push(message);
      await adminsRef.child(getAdminId()).set({ name: getAdminName(), addedAt: Date.now() });
      alcInput.value = '';
      alcPendingImage = null;
      document.getElementById('alc-img-bar')?.classList.add('hidden');
      alcClearReply();
      alcInput.focus();
    } catch (err) {
      console.error(err);
      alert('ارسال ناموفق بود.');
    } finally {
      if (btn) btn.disabled = false;
    }
  });
}

// پروفایل
document.getElementById('alc-profile-btn')?.addEventListener('click', () => {
  updateAlcAvatarUI();
  document.getElementById('alc-profile-modal')?.classList.remove('hidden');
});
document.getElementById('alc-av-close')?.addEventListener('click', () => {
  document.getElementById('alc-profile-modal')?.classList.add('hidden');
});
document.getElementById('alc-profile-bg')?.addEventListener('click', () => {
  document.getElementById('alc-profile-modal')?.classList.add('hidden');
});
document.getElementById('alc-av-change')?.addEventListener('click', () => {
  document.getElementById('alc-av-file')?.click();
});
document.getElementById('alc-av-file')?.addEventListener('change', async () => {
  const file = document.getElementById('alc-av-file').files?.[0];
  if (!file) return;
  try {
    const blob = await compressImage(file, 240, 0.55);
    const dataUrl = await blobToDataUrl(blob);
    setAdminAvatar(dataUrl);
  } catch (e) {
    alert('بارگذاری عکس ناموفق');
  }
});
document.getElementById('alc-av-remove')?.addEventListener('click', () => setAdminAvatar(null));

updateAlcAvatarUI();
