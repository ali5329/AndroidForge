package com.armila.app.data

import android.content.Context
import com.armila.app.util.MessageGenerator
import com.armila.app.worker.AlarmScheduler
import com.armila.app.worker.CatchUpNotifier
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class MessageRepository(context: Context) {

    private val appContext = context.applicationContext
    private val dao = AppDatabase.getInstance(appContext).messageDao()
    private val prefs = PreferencesManager(appContext)

    val allMessages: Flow<List<MessageEntity>> = dao.getAllMessages()
    val latestMessage: Flow<MessageEntity?> = dao.getLatestMessage()
    val messageCount: Flow<Int> = dao.getMessageCount()
    val nextIndexFlow: Flow<Long> = prefs.nextMessageIndex
    val lastNotificationTime: Flow<Long> = prefs.lastNotificationTime
    val unreadCount: Flow<Int> = prefs.unreadCount

    suspend fun getNextIndex(): Long = prefs.nextMessageIndex.first()

    suspend fun getLastNotificationTime(): Long = prefs.lastNotificationTime.first()

    suspend fun deliverNextMessage(): Pair<MessageEntity, Int> {
        val index = prefs.nextMessageIndex.first()
        val content = MessageGenerator.generate(index)
        val entity = MessageEntity(
            messageIndex = index,
            content = content,
            receivedAt = System.currentTimeMillis()
        )
        val newId = dao.insert(entity)
        val saved = entity.copy(id = newId)
        val next = MessageGenerator.nextIndex(index)
        prefs.setNextMessageIndex(next)
        prefs.setLastNotificationTime(System.currentTimeMillis())
        val unread = prefs.incrementUnreadCount()
        return saved to unread
    }

    /**
     * If last message is older than 60 minutes, deliver missed ones (max 3)
     * and reschedule the alarm. Returns how many were delivered.
     */
    suspend fun catchUpIfNeeded(): Int {
        val last = prefs.lastNotificationTime.first()
        val now = System.currentTimeMillis()

        if (last <= 0L) {
            val (msg, unread) = deliverNextMessage()
            CatchUpNotifier.notify(appContext, msg.content, msg.id, unread)
            AlarmScheduler.scheduleNext(appContext)
            return 1
        }

        if (now - last < AlarmScheduler.INTERVAL_MS) {
            AlarmScheduler.scheduleNext(appContext, last)
            return 0
        }

        var delivered = 0
        var from = last
        while (now - from >= AlarmScheduler.INTERVAL_MS && delivered < 3) {
            val (msg, unread) = deliverNextMessage()
            CatchUpNotifier.notify(appContext, msg.content, msg.id, unread)
            from += AlarmScheduler.INTERVAL_MS
            delivered++
        }
        AlarmScheduler.scheduleNext(appContext)
        return delivered
    }

    suspend fun markFirstLaunchDone() {
        prefs.setFirstLaunchDone()
    }

    suspend fun isFirstLaunchDone(): Boolean = prefs.isFirstLaunchDone.first()

    suspend fun clearUnread() {
        prefs.clearUnreadCount()
    }
}
