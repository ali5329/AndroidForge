package com.armila.app.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.armila.app.MainActivity
import com.armila.app.R
import com.armila.app.data.MessageRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Fired by AlarmManager every ~60 minutes to deliver the next romantic message.
 */
class MessageAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != ACTION_DELIVER) return

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val repository = MessageRepository(context.applicationContext)
                val (message, unreadCount) = repository.deliverNextMessage()
                showNotification(context.applicationContext, message.content, message.id, unreadCount)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to deliver message", e)
            } finally {
                // Always schedule the next one
                AlarmScheduler.scheduleNext(context.applicationContext)
                pendingResult.finish()
            }
        }
    }

    private fun showNotification(
        context: Context,
        content: String,
        messageId: Long,
        unreadCount: Int
    ) {
        createChannel(context)

        val soundUri = Uri.parse("android.resource://${context.packageName}/${R.raw.armila_notif}")

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(EXTRA_MESSAGE_ID, messageId)
            data = Uri.parse("armila://message/$messageId")
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            messageId.toInt().and(0x7FFFFFFF),
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notifId = (NOTIFICATION_ID_BASE + (messageId % 40_000)).toInt()

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("آرمیلا ❤️")
            .setContentText(content)
            .setStyle(NotificationCompat.BigTextStyle().bigText(content))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setSound(soundUri)
            .setVibrate(longArrayOf(0, 300, 200, 300))
            .setOnlyAlertOnce(false)
            .setGroup(GROUP_KEY)
            .setNumber(unreadCount)
            .build()

        val summaryIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val summaryPending = PendingIntent.getActivity(
            context,
            0,
            summaryIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val summary = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("آرمیلا ❤️")
            .setContentText("$unreadCount پیام عاشقانه جدید")
            .setStyle(
                NotificationCompat.InboxStyle()
                    .setSummaryText("$unreadCount پیام خوانده‌نشده")
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .setContentIntent(summaryPending)
            .setGroup(GROUP_KEY)
            .setGroupSummary(true)
            .setNumber(unreadCount)
            .setOnlyAlertOnce(true)
            .setSound(null)
            .build()

        with(NotificationManagerCompat.from(context)) {
            try {
                notify(notifId, notification)
                notify(SUMMARY_ID, summary)
            } catch (_: SecurityException) {
            }
        }
    }

    private fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val soundUri = Uri.parse("android.resource://${context.packageName}/${R.raw.armila_notif}")
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()

            val channel = NotificationChannel(
                CHANNEL_ID,
                context.getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = context.getString(R.string.notification_channel_desc)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 300, 200, 300)
                setSound(soundUri, attrs)
                setShowBadge(true)
            }
            val manager = context.getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    companion object {
        const val ACTION_DELIVER = "com.armila.app.ACTION_DELIVER_MESSAGE"
        const val TAG = "ArmilaAlarmReceiver"
        const val CHANNEL_ID = "armila_love_messages_v2"
        const val GROUP_KEY = "com.armila.app.MESSAGES"
        const val NOTIFICATION_ID_BASE = 2000
        const val SUMMARY_ID = 1999
        const val EXTRA_MESSAGE_ID = "extra_message_id"

        fun clearBadge(context: Context) {
            try {
                NotificationManagerCompat.from(context).cancel(SUMMARY_ID)
            } catch (_: Exception) {
            }
        }
    }
}
