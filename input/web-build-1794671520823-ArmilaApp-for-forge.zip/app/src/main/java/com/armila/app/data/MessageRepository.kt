package com.armila.app.data

import android.content.Context
import com.armila.app.util.MessageGenerator
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class MessageRepository(context: Context) {

    private val dao = AppDatabase.getInstance(context).messageDao()
    private val prefs = PreferencesManager(context)

    val allMessages: Flow<List<MessageEntity>> = dao.getAllMessages()
    val latestMessage: Flow<MessageEntity?> = dao.getLatestMessage()
    val messageCount: Flow<Int> = dao.getMessageCount()
    val nextIndexFlow: Flow<Long> = prefs.nextMessageIndex

    suspend fun getNextIndex(): Long = prefs.nextMessageIndex.first()

    /**
     * Generates the next unique message, stores it, advances the index (wraps at 1M),
     * and returns the new entity.
     */
    suspend fun deliverNextMessage(): MessageEntity {
        val index = prefs.nextMessageIndex.first()
        val content = MessageGenerator.generate(index)
        val entity = MessageEntity(
            messageIndex = index,
            content = content,
            receivedAt = System.currentTimeMillis()
        )
        dao.insert(entity)
        val next = MessageGenerator.nextIndex(index)
        prefs.setNextMessageIndex(next)
        prefs.setLastNotificationTime(System.currentTimeMillis())
        return entity
    }

    suspend fun markFirstLaunchDone() {
        prefs.setFirstLaunchDone()
    }

    suspend fun isFirstLaunchDone(): Boolean = prefs.isFirstLaunchDone.first()
}
