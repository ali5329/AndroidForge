// ============================================
// تنظیمات Firebase
// ============================================
const firebaseConfig = {
  apiKey: "AIzaSyBWkd5Zi_1Pb9zThRGun69VcOwYaNyDckw",
  authDomain: "sample-firebase-ai-app-f211a.firebaseapp.com",
  databaseURL: "https://sample-firebase-ai-app-f211a-default-rtdb.firebaseio.com",
  projectId: "sample-firebase-ai-app-f211a",
  storageBucket: "sample-firebase-ai-app-f211a.firebasestorage.app",
  messagingSenderId: "689511797055",
  appId: "1:689511797055:web:5269152f011d284962438a"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.database();
const storage = firebase.storage();
const messagesRef = db.ref('messages');
const presenceRef = db.ref('presence');
const privateRef = db.ref('privateChats');

// DOM
const loginScreen = document.getElementById('login-screen');
const chatScreen = document.getElementById('chat-screen');
const loginForm = document.getElementById('login-form');
const firstNameInput = document.getElementById('first-name');
const lastNameInput = document.getElementById('last-name');
const messagesContainer = document.getElementById('messages');
const messageForm = document.getElementById('message-form');
const messageInput = document.getElementById('message-input');
const sendBtn = document.getElementById('send-btn');
const onlineCountEl = document.getElementById('online-count');
const onlineStatusEl = document.getElementById('online-status');
const replyBar = document.getElementById('reply-bar');
const replyToNameEl = document.getElementById('reply-to-name');
const replyToTextEl = document.getElementById('reply-to-text');
const cancelReplyBtn = document.getElementById('cancel-reply-btn');
const chatTitle = document.getElementById('chat-title');
const backBtn = document.getElementById('back-btn');
const privateSubtitle = document.getElementById('private-subtitle');
const attachBtn = document.getElementById('attach-btn');
const imageInput = document.getElementById('image-input');
const imagePreviewBar = document.getElementById('image-preview-bar');
const imagePreviewThumb = document.getElementById('image-preview-thumb');
const imagePreviewName = document.getElementById('image-preview-name');
const cancelImageBtn = document.getElementById('cancel-image-btn');
const lightbox = document.getElementById('lightbox');
const lightboxImg = document.getElementById('lightbox-img');
const lightboxClose = document.getElementById('lightbox-close');

let currentUser = null;
let messagesListener = null;
let presenceListener = null;
let connectedListener = null;
let myPresenceRef = null;
let replyToMessage = null;
let pendingImageFile = null;
let pendingImageDataUrl = null;

let chatMode = 'public';
let privatePartner = null;
let currentMessagesRef = messagesRef;

// شمارش پیام‌های خوانده‌نشده برای نوتیف
let unreadCount = 0;
let appInForeground = true;
let lastKnownMessageKey = null;
let isInitialLoad = true;

// ورود قبلی
const savedUser = localStorage.getItem('chatUser');
if (savedUser) {
  try {
    currentUser = JSON.parse(savedUser);
    if (!currentUser.fullName && currentUser.firstName) {
      currentUser.fullName = `${currentUser.firstName} ${currentUser.lastName || ''}`.trim();
    }
    showChat();
  } catch (e) {
    localStorage.removeItem('chatUser');
  }
}

loginForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const firstName = firstNameInput.value.trim();
  const lastName = lastNameInput.value.trim();
  if (!firstName || !lastName) return;

  currentUser = {
    firstName,
    lastName,
    fullName: `${firstName} ${lastName}`,
    displayName: `${firstName} ${lastName}`,
    id: Date.now().toString(36) + Math.random().toString(36).substr(2, 5)
  };

  localStorage.setItem('chatUser', JSON.stringify(currentUser));
  showChat();
});

function showChat() {
  loginScreen.classList.remove('active');
  chatScreen.classList.add('active');
  openPublicChat();
  setupPresence();
  messageInput.focus();
}

function getPrivateChatId(userId1, userId2) {
  return [userId1, userId2].sort().join('_');
}

function openPublicChat() {
  if (messagesListener && currentMessagesRef) {
    currentMessagesRef.off('child_added', messagesListener);
    messagesListener = null;
  }
  chatMode = 'public';
  privatePartner = null;
  currentMessagesRef = messagesRef;
  isInitialLoad = true;
  chatTitle.textContent = 'گروه عمومی';
  onlineStatusEl.classList.remove('hidden');
  privateSubtitle.classList.add('hidden');
  backBtn.classList.add('hidden');
  cancelReply();
  clearPendingImage();
  messageInput.placeholder = 'پیام خود را بنویسید...';
  loadMessages();
  // خواندن پیام‌ها → پاک کردن badge
  clearUnreadBadge();
}

function openPrivateChat(partnerId, partnerName) {
  if (!partnerId || partnerId === currentUser.id) return;
  if (messagesListener && currentMessagesRef) {
    currentMessagesRef.off('child_added', messagesListener);
    messagesListener = null;
  }
  chatMode = 'private';
  privatePartner = { id: partnerId, name: partnerName };
  const chatId = getPrivateChatId(currentUser.id, partnerId);
  currentMessagesRef = privateRef.child(chatId).child('messages');
  isInitialLoad = true;

  privateRef.child(chatId).child('meta').update({
    users: {
      [currentUser.id]: currentUser.displayName || currentUser.fullName,
      [partnerId]: partnerName
    },
    updatedAt: firebase.database.ServerValue.TIMESTAMP
  });

  chatTitle.textContent = partnerName;
  onlineStatusEl.classList.add('hidden');
  privateSubtitle.classList.remove('hidden');
  backBtn.classList.remove('hidden');
  cancelReply();
  clearPendingImage();
  messageInput.placeholder = 'پیام خصوصی به ' + partnerName + '...';
  loadMessages();
  messageInput.focus();
}

backBtn.addEventListener('click', () => openPublicChat());

// ==================== Presence ====================
function setupPresence() {
  if (!currentUser) return;
  if (connectedListener) db.ref('.info/connected').off('value', connectedListener);
  if (presenceListener) presenceRef.off('value', presenceListener);

  connectedListener = db.ref('.info/connected').on('value', (snap) => {
    if (snap.val() === true && currentUser) {
      myPresenceRef = presenceRef.child(currentUser.id);
      myPresenceRef.onDisconnect().remove().then(() => {
        myPresenceRef.set({
          name: currentUser.displayName || currentUser.fullName,
          lastSeen: firebase.database.ServerValue.TIMESTAMP
        });
      });
    }
  });

  presenceListener = presenceRef.on('value', (snapshot) => {
    const count = snapshot.exists() ? snapshot.numChildren() : 0;
    updateOnlineCount(count);
  }, () => { onlineCountEl.textContent = 'آفلاین'; });
}

function updateOnlineCount(count) {
  if (count <= 0) onlineCountEl.textContent = 'هیچ‌کس آنلاین نیست';
  else if (count === 1) onlineCountEl.textContent = '۱ نفر آنلاین';
  else onlineCountEl.textContent = toPersianNum(count) + ' نفر آنلاین';
}

function stopPresence() {
  if (myPresenceRef) { myPresenceRef.remove().catch(() => {}); myPresenceRef = null; }
}

function toPersianNum(n) {
  const p = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
  return String(n).replace(/\d/g, d => p[d]);
}

// ==================== Messages ====================
function loadMessages() {
  messagesContainer.innerHTML = '<div class="loading">در حال بارگذاری پیام‌ها...</div>';
  const ref = currentMessagesRef;

  ref.limitToLast(100).once('value', (snapshot) => {
    if (ref !== currentMessagesRef) return;
    messagesContainer.innerHTML = '';
    if (!snapshot.exists()) {
      const emptyText = chatMode === 'private'
        ? 'هنوز پیامی با این کاربر ندارید<br>اولین پیام را بفرستید!'
        : 'هنوز پیامی نیست<br>اولین پیام را بفرستید!';
      messagesContainer.innerHTML = `
        <div class="empty-state">
          <span>${chatMode === 'private' ? '🔒' : '💬'}</span>
          <p>${emptyText}</p>
        </div>`;
    } else {
      snapshot.forEach((child) => {
        appendMessage(child.val(), child.key);
        lastKnownMessageKey = child.key;
      });
      scrollToBottom();
    }
    isInitialLoad = false;

    if (messagesListener) ref.off('child_added', messagesListener);
    messagesListener = ref.limitToLast(100).on('child_added', (snap) => {
      if (ref !== currentMessagesRef) return;
      if (document.querySelector(`[data-id="${snap.key}"]`)) return;

      const empty = messagesContainer.querySelector('.empty-state');
      if (empty) empty.remove();
      const loading = messagesContainer.querySelector('.loading');
      if (loading) loading.remove();

      const msg = snap.val();
      appendMessage(msg, snap.key);
      scrollToBottom();

      // نوتیف فقط برای پیام‌های جدید دیگران در گروه عمومی
      if (!isInitialLoad && msg.userId !== currentUser.id) {
        if (chatMode === 'public' || !appInForeground) {
          onNewMessageNotification(msg);
        }
      }
      lastKnownMessageKey = snap.key;
    });
  }, () => {
    messagesContainer.innerHTML = '<div class="loading">خطا در اتصال به سرور</div>';
  });
}

function appendMessage(msg, id) {
  const isMe = msg.userId === currentUser.id;
  const time = formatTime(msg.timestamp);
  const div = document.createElement('div');
  div.className = `message ${isMe ? 'me' : 'other'}`;
  div.dataset.id = id;

  let replyHtml = '';
  if (msg.replyTo) {
    replyHtml = `
      <div class="reply-preview" data-reply-id="${escapeHtml(msg.replyTo.id || '')}">
        <span class="reply-preview-name">${escapeHtml(msg.replyTo.name || '')}</span>
        <span class="reply-preview-text">${escapeHtml(msg.replyTo.text || '')}</span>
      </div>`;
  }

  let contentHtml = '';
  if (msg.imageUrl) {
    contentHtml += `<img class="message-image" src="${escapeHtml(msg.imageUrl)}" alt="عکس" loading="lazy">`;
  }
  if (msg.text) {
    contentHtml += `<div class="message-text">${escapeHtml(msg.text)}</div>`;
  }

  const safeName = escapeHtml(msg.name || '');
  const safeUserId = escapeHtml(msg.userId || '');
  const nameClass = isMe ? 'message-name' : 'message-name clickable-name';
  const nameAttrs = isMe ? '' : `data-userid="${safeUserId}" data-username="${safeName}"`;

  div.innerHTML = `
    <div class="message-meta">
      <span class="${nameClass}" ${nameAttrs}>${safeName}</span>
      <span class="message-time">${time}</span>
    </div>
    <div class="message-bubble">
      ${replyHtml}
      ${contentHtml}
    </div>
    <div class="message-actions">
      <button type="button" class="btn-reply">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <polyline points="9 17 4 12 9 7"></polyline>
          <path d="M20 18v-2a4 4 0 0 0-4-4H4"></path>
        </svg>
        پاسخ
      </button>
    </div>`;

  if (!isMe && chatMode === 'public') {
    const nameEl = div.querySelector('.clickable-name');
    if (nameEl) {
      nameEl.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        openPrivateChat(nameEl.dataset.userid, nameEl.dataset.username);
      });
    }
  }

  const imgEl = div.querySelector('.message-image');
  if (imgEl) {
    imgEl.addEventListener('click', () => openLightbox(msg.imageUrl));
  }

  div.querySelector('.btn-reply').addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    setReplyTo({
      id,
      name: msg.name || '',
      text: msg.text || (msg.imageUrl ? '📷 عکس' : '')
    });
  });

  const rp = div.querySelector('.reply-preview');
  if (rp) {
    rp.addEventListener('click', (e) => {
      e.stopPropagation();
      const t = document.querySelector(`[data-id="${rp.dataset.replyId}"]`);
      if (t) {
        t.scrollIntoView({ behavior: 'smooth', block: 'center' });
        t.classList.add('highlight');
        setTimeout(() => t.classList.remove('highlight'), 1500);
      }
    });
  }

  messagesContainer.appendChild(div);
}

// ==================== Image ====================
attachBtn.addEventListener('click', () => imageInput.click());

imageInput.addEventListener('change', () => {
  const file = imageInput.files && imageInput.files[0];
  if (!file) return;
  if (!file.type.startsWith('image/')) {
    alert('فقط فایل تصویری مجاز است.');
    return;
  }
  if (file.size > 8 * 1024 * 1024) {
    alert('حجم عکس نباید بیشتر از ۸ مگابایت باشد.');
    return;
  }
  pendingImageFile = file;
  const reader = new FileReader();
  reader.onload = (e) => {
    pendingImageDataUrl = e.target.result;
    imagePreviewThumb.src = pendingImageDataUrl;
    imagePreviewName.textContent = file.name || 'عکس';
    imagePreviewBar.classList.remove('hidden');
    sendBtn.disabled = false;
  };
  reader.readAsDataURL(file);
});

cancelImageBtn.addEventListener('click', clearPendingImage);

function clearPendingImage() {
  pendingImageFile = null;
  pendingImageDataUrl = null;
  imageInput.value = '';
  imagePreviewBar.classList.add('hidden');
  imagePreviewThumb.src = '';
  sendBtn.disabled = messageInput.value.trim().length === 0;
}

function compressImage(file, maxWidth, quality) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      URL.revokeObjectURL(url);
      let w = img.width, h = img.height;
      if (w > maxWidth) {
        h = Math.round(h * maxWidth / w);
        w = maxWidth;
      }
      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      canvas.getContext('2d').drawImage(img, 0, 0, w, h);
      canvas.toBlob((blob) => {
        if (blob) resolve(blob);
        else reject(new Error('فشرده‌سازی ناموفق'));
      }, 'image/jpeg', quality);
    };
    img.onerror = () => reject(new Error('خواندن عکس ناموفق'));
    img.src = url;
  });
}

async function uploadImage(file) {
  const compressed = await compressImage(file, 1280, 0.72);
  const path = `chat_images/${Date.now()}_${Math.random().toString(36).slice(2, 8)}.jpg`;
  const ref = storage.ref(path);
  await ref.put(compressed, { contentType: 'image/jpeg' });
  return await ref.getDownloadURL();
}

function openLightbox(url) {
  lightboxImg.src = url;
  lightbox.classList.remove('hidden');
}
lightboxClose.addEventListener('click', () => {
  lightbox.classList.add('hidden');
  lightboxImg.src = '';
});
lightbox.addEventListener('click', (e) => {
  if (e.target === lightbox) {
    lightbox.classList.add('hidden');
    lightboxImg.src = '';
  }
});

// ==================== Reply ====================
function setReplyTo(msg) {
  replyToMessage = msg;
  replyToNameEl.textContent = msg.name;
  const shortText = (msg.text || '').length > 40 ? msg.text.slice(0, 40) + '…' : (msg.text || '');
  replyToTextEl.textContent = shortText;
  replyBar.classList.remove('hidden');
  messageInput.focus();
}
function cancelReply() {
  replyToMessage = null;
  replyBar.classList.add('hidden');
  replyToNameEl.textContent = '';
  replyToTextEl.textContent = '';
}
cancelReplyBtn.addEventListener('click', cancelReply);

// ==================== Send ====================
messageForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const text = messageInput.value.trim();
  if ((!text && !pendingImageFile) || !currentUser) return;

  sendBtn.disabled = true;
  attachBtn.disabled = true;

  try {
    let imageUrl = null;
    if (pendingImageFile) {
      const status = document.createElement('div');
      status.className = 'upload-status';
      status.textContent = 'در حال آپلود عکس...';
      messageForm.parentNode.insertBefore(status, messageForm);
      try {
        imageUrl = await uploadImage(pendingImageFile);
      } finally {
        status.remove();
      }
    }

    const displayName = currentUser.displayName || currentUser.fullName;
    const message = {
      name: displayName,
      userId: currentUser.id,
      timestamp: firebase.database.ServerValue.TIMESTAMP
    };
    if (text) message.text = text;
    if (imageUrl) message.imageUrl = imageUrl;
    if (replyToMessage) {
      message.replyTo = {
        id: replyToMessage.id,
        name: replyToMessage.name,
        text: (replyToMessage.text || '').length > 80
          ? replyToMessage.text.slice(0, 80) + '…'
          : (replyToMessage.text || '📷 عکس')
      };
    }

    await currentMessagesRef.push(message);

    if (chatMode === 'private' && privatePartner) {
      const chatId = getPrivateChatId(currentUser.id, privatePartner.id);
      privateRef.child(chatId).child('meta').update({
        updatedAt: firebase.database.ServerValue.TIMESTAMP,
        lastMessage: text || '📷 عکس'
      });
    }

    messageInput.value = '';
    clearPendingImage();
    cancelReply();
    messageInput.focus();
  } catch (err) {
    console.error(err);
    alert('خطا در ارسال. اینترنت و تنظیمات Firebase Storage را بررسی کنید.');
  } finally {
    sendBtn.disabled = messageInput.value.trim().length === 0 && !pendingImageFile;
    attachBtn.disabled = false;
  }
});

messageInput.addEventListener('input', () => {
  sendBtn.disabled = messageInput.value.trim().length === 0 && !pendingImageFile;
});

function scrollToBottom() {
  requestAnimationFrame(() => {
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  });
}

function formatTime(timestamp) {
  if (!timestamp) return '';
  const date = new Date(timestamp);
  const now = new Date();
  const isToday = date.toDateString() === now.toDateString();
  const h = date.getHours().toString().padStart(2, '0');
  const m = date.getMinutes().toString().padStart(2, '0');
  if (isToday) return `${h}:${m}`;
  return `${date.getDate()}/${date.getMonth() + 1} ${h}:${m}`;
}

function escapeHtml(text) {
  if (!text) return '';
  const d = document.createElement('div');
  d.textContent = text;
  return d.innerHTML;
}

messageInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    if (!sendBtn.disabled) messageForm.dispatchEvent(new Event('submit'));
  }
});

// ==================== Notifications ====================
function onNewMessageNotification(msg) {
  if (msg.userId === currentUser.id) return;

  unreadCount++;
  const title = msg.name || 'پیام جدید';
  const body = msg.text || (msg.imageUrl ? 'یک عکس ارسال شد' : 'پیام جدید');

  // نوتیفیکیشن native اندروید
  if (window.AndroidBridge && window.AndroidBridge.showNotification) {
    try {
      window.AndroidBridge.showNotification(title, body, unreadCount);
    } catch (e) { console.warn(e); }
  }

  // Web Notification (در صورت پشتیبانی)
  if ('Notification' in window && Notification.permission === 'granted' && !appInForeground) {
    try {
      new Notification(title, { body, tag: 'chat-msg', renotify: true });
    } catch (e) {}
  }
}

function clearUnreadBadge() {
  unreadCount = 0;
  if (window.AndroidBridge && window.AndroidBridge.clearNotifications) {
    try { window.AndroidBridge.clearNotifications(); } catch (e) {}
  }
}

// درخواست مجوز نوتیف وب
if ('Notification' in window && Notification.permission === 'default') {
  Notification.requestPermission().catch(() => {});
}

document.addEventListener('visibilitychange', () => {
  appInForeground = document.visibilityState === 'visible';
  if (appInForeground && chatMode === 'public') {
    clearUnreadBadge();
  }
  if (appInForeground && currentUser && myPresenceRef) {
    myPresenceRef.set({
      name: currentUser.displayName || currentUser.fullName,
      lastSeen: firebase.database.ServerValue.TIMESTAMP
    });
  }
});

window.addEventListener('beforeunload', stopPresence);

// لیسنر جدا برای نوتیف گروه عمومی وقتی در پی‌وی هستیم یا پس‌زمینه
messagesRef.limitToLast(1).on('child_added', (snap) => {
  if (isInitialLoad) return;
  const msg = snap.val();
  if (!msg || !currentUser || msg.userId === currentUser.id) return;
  // اگر الان در گروه عمومی و foreground هستیم، loadMessages خودش هندل می‌کند
  if (chatMode === 'public' && appInForeground) return;
  // اگر کلید جدید است
  if (snap.key === lastKnownMessageKey) return;
  onNewMessageNotification(msg);
});
