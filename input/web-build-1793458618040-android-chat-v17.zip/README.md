# چت ساده v1.5

## ویژگی‌ها
- چت گروهی + چت خصوصی (کلیک روی نام)
- تعداد آنلاین
- ریپلای
- ارسال عکس (دکمه سنجاق)
- نوتیفیکیشن پیام جدید + badge روی آیکون

## Firebase
1. در app.js مقدار firebaseConfig را عوض کن
2. Realtime Database و Storage را فعال کن
3. قوانین نمونه:

Realtime Database:
{ "rules": { ".read": true, ".write": true } }

Storage:
{ "rules": { ".read": true, ".write": true } }
