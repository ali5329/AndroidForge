package com.ghazal.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val SoftPink = Color(0xFFF5C6D6)
val Gold = Color(0xFFFFD700)
val DeepPink = Color(0xFFFF69B4)
val PurpleDark = Color(0xFF2A1040)
val Bg = Color(0xFF0D0D12)
val CardBg = Color(0xFF1A1228)

private val scheme = darkColorScheme(
    primary = Gold, onPrimary = Color.Black,
    secondary = SoftPink, background = Bg, surface = CardBg,
    onBackground = SoftPink, onSurface = SoftPink
)

@Composable
fun GhazalTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
