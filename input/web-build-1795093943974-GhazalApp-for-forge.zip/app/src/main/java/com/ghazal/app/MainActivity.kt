package com.ghazal.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.ghazal.app.data.Repository
import com.ghazal.app.ui.BirthdayScreen
import com.ghazal.app.ui.MainScreen
import com.ghazal.app.ui.WelcomeScreen
import com.ghazal.app.ui.theme.GhazalTheme
import com.ghazal.app.util.TargetTime
import com.ghazal.app.worker.AlarmScheduler
import com.ghazal.app.worker.NotifHelper
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
    private lateinit var repo: Repository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        repo = Repository(this)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        requestExactAlarm()
        requestBattery()

        val openBirthday = intent?.getBooleanExtra("open_birthday", false) == true

        setContent {
            GhazalTheme {
                Surface(Modifier.fillMaxSize()) {
                    var showWelcome by remember { mutableStateOf(true) }
                    var showBirthday by remember { mutableStateOf(openBirthday) }
                    var birthdayKey by remember { mutableIntStateOf(0) }
                    val scope = rememberCoroutineScope()

                    LaunchedEffect(Unit) {
                        repo.syncNetworkTime()
                        if (repo.isFirstDone()) showWelcome = false
                        if (repo.isBirthdayPending() || TargetTime.isBirthdayReached(repo.trustedNow())) {
                            showBirthday = true
                        }
                    }

                    LaunchedEffect(showBirthday) {
                        if (showBirthday) repo.markBirthdayShown()
                    }

                    when {
                        showWelcome -> WelcomeScreen {
                            scope.launch {
                                repo.markFirstDone()
                                repo.catchUpIfNeeded()
                                AlarmScheduler.scheduleNext(this@MainActivity)
                                showWelcome = false
                            }
                        }
                        showBirthday -> key(birthdayKey) {
                            BirthdayScreen(onReplay = { birthdayKey++ })
                        }
                        else -> MainScreen(onShowBirthday = {
                            scope.launch {
                                repo.markBirthdayPending()
                                showBirthday = true
                            }
                        })
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        lifecycleScope.launch {
            try {
                repo.syncNetworkTime()
                if (!TargetTime.isBirthdayReached(repo.trustedNow())) {
                    repo.catchUpIfNeeded()
                } else {
                    repo.markBirthdayPending()
                }
                repo.clearUnread()
                NotifHelper.clearBadge(this@MainActivity)
                AlarmScheduler.ensureScheduled(this@MainActivity)
            } catch (_: Exception) { }
        }
    }

    private fun requestExactAlarm() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                val am = getSystemService(ALARM_SERVICE) as android.app.AlarmManager
                if (!am.canScheduleExactAlarms()) {
                    startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                        data = Uri.parse("package:$packageName")
                    })
                }
            } catch (_: Exception) { }
        }
    }

    @SuppressLint("BatteryLife")
    private fun requestBattery() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                })
            }
        } catch (_: Exception) { }
    }
}
