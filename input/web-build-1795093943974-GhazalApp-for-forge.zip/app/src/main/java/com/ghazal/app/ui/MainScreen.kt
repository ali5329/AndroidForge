package com.ghazal.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ghazal.app.data.MessageEntity
import com.ghazal.app.ui.theme.*
import com.ghazal.app.util.TargetTime
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

@Composable
fun MainScreen(
    viewModel: MainViewModel = viewModel(),
    onShowBirthday: () -> Unit = {}
) {
    val latest by viewModel.latest.collectAsState()
    val history by viewModel.messages.collectAsState()
    val count by viewModel.count.collectAsState()
    val bdayPending by viewModel.birthdayPending.collectAsState()
    val bdayShown by viewModel.birthdayShown.collectAsState()
    val context = LocalContext.current

    var remaining by remember { mutableLongStateOf(TargetTime.remainingMs()) }
    LaunchedEffect(Unit) {
        while (true) {
            remaining = TargetTime.remainingMs()
            if (remaining == 0L && (bdayPending || !bdayShown)) {
                onShowBirthday()
            }
            delay(1000)
        }
    }

    val days = TimeUnit.MILLISECONDS.toDays(remaining)
    val hours = TimeUnit.MILLISECONDS.toHours(remaining) % 24
    val mins = TimeUnit.MILLISECONDS.toMinutes(remaining) % 60
    val secs = TimeUnit.MILLISECONDS.toSeconds(remaining) % 60

    Column(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Bg, PurpleDark, Bg))
        ).padding(16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("غزل ❤️", color = SoftPink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Icon(Icons.Default.Favorite, null, tint = Gold, modifier = Modifier.size(26.dp))
        }
        Spacer(Modifier.height(16.dp))

        // Countdown card
        Card(
            Modifier.fillMaxWidth().border(1.dp, Brush.linearGradient(listOf(Gold.copy(0.6f), SoftPink.copy(0.3f))), RoundedCornerShape(20.dp)),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(CardBg)
        ) {
            Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("تا یک لحظه خاص", color = SoftPink.copy(0.8f), fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                if (remaining > 0) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TimeBlock(days.toString(), "روز")
                        TimeBlock(String.format(Locale.US, "%02d", hours), "ساعت")
                        TimeBlock(String.format(Locale.US, "%02d", mins), "دقیقه")
                        TimeBlock(String.format(Locale.US, "%02d", secs), "ثانیه")
                    }
                } else {
                    Text("🎉", fontSize = 36.sp)
                    Text("لحظه خاص رسیده!", color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    TextButton(onClick = onShowBirthday) {
                        Text("مشاهده جشن", color = Gold)
                    }
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        // Latest message
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(CardBg)) {
            Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("آخرین پیام", color = SoftPink.copy(0.7f), fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                if (latest != null) {
                    Text(latest!!.content, color = SoftPink, fontSize = 16.sp, textAlign = TextAlign.Center, lineHeight = 26.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(formatDate(latest!!.receivedAt), color = SoftPink.copy(0.5f), fontSize = 11.sp)
                        IconButton(onClick = { copy(context, latest!!.content) }) {
                            Icon(Icons.Default.ContentCopy, "کپی", tint = Gold, modifier = Modifier.size(18.dp))
                        }
                    }
                } else {
                    Text("هنوز پیامی نرسیده ✨", color = SoftPink.copy(0.6f))
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatBox(Icons.Default.NotificationsActive, count.toString(), "دریافت‌شده", Modifier.weight(1f))
            StatBox(Icons.Default.Favorite, if (remaining > 0) "..." else "✓", "وضعیت", Modifier.weight(1f))
        }

        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.History, null, tint = Gold, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("تاریخچه پیام‌ها", color = SoftPink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(8.dp))

        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(history, key = { it.id }) { msg ->
                Card(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { copy(context, msg.content) },
                    colors = CardDefaults.cardColors(CardBg.copy(0.9f))) {
                    Column(Modifier.padding(12.dp)) {
                        Text(msg.content, color = SoftPink, fontSize = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        Text(formatDate(msg.receivedAt), color = SoftPink.copy(0.5f), fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun TimeBlock(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = TextStyle(color = Gold, fontSize = 28.sp, fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace, shadow = Shadow(Gold.copy(0.5f), blurRadius = 12f)))
        Text(label, color = SoftPink.copy(0.7f), fontSize = 11.sp)
    }
}

@Composable
private fun StatBox(icon: androidx.compose.ui.graphics.vector.ImageVector, value: String, label: String, modifier: Modifier) {
    Card(modifier, shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(CardBg)) {
        Column(Modifier.padding(12.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = Gold, modifier = Modifier.size(20.dp))
            Text(value, color = SoftPink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(label, color = SoftPink.copy(0.6f), fontSize = 11.sp)
        }
    }
}

private fun formatDate(ms: Long): String =
    SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale("fa", "IR")).format(Date(ms))

private fun copy(ctx: Context, text: String) {
    (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
        .setPrimaryClip(ClipData.newPlainText("ghazal", text))
    Toast.makeText(ctx, "کپی شد ❤️", Toast.LENGTH_SHORT).show()
}
