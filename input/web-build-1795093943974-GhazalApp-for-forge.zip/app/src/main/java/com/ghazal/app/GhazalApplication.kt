package com.ghazal.app

import android.app.Application
import com.ghazal.app.worker.AlarmScheduler
import com.ghazal.app.worker.NotifHelper

class GhazalApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        NotifHelper.ensureChannels(this)
        AlarmScheduler.ensureScheduled(this)
        AlarmScheduler.scheduleBirthday(this)
    }
}
