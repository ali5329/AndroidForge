package com.ghazal.app.worker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val a = intent?.action ?: return
        if (a == Intent.ACTION_BOOT_COMPLETED || a == Intent.ACTION_MY_PACKAGE_REPLACED ||
            a == "android.intent.action.QUICKBOOT_POWERON") {
            AlarmScheduler.ensureScheduled(context.applicationContext)
            AlarmScheduler.scheduleBirthday(context.applicationContext)
        }
    }
}
