package com.ghazal.app.worker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.ghazal.app.data.Repository
import com.ghazal.app.util.TargetTime
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MessageAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val repo = Repository(context.applicationContext)
                when (action) {
                    ACTION_DELIVER -> {
                        if (!TargetTime.isBirthdayReached(repo.trustedNow())) {
                            val (msg, unread) = repo.deliverNextMessage()
                            NotifHelper.showMessage(context, msg.content, msg.id, unread)
                            AlarmScheduler.scheduleNext(context)
                        } else {
                            repo.markBirthdayPending()
                            NotifHelper.showBirthday(context)
                        }
                    }
                    ACTION_BIRTHDAY -> {
                        repo.markBirthdayPending()
                        NotifHelper.showBirthday(context)
                    }
                }
            } catch (_: Exception) {
            } finally {
                pending.finish()
            }
        }
    }

    companion object {
        const val ACTION_DELIVER = "com.ghazal.app.ACTION_DELIVER"
        const val ACTION_BIRTHDAY = "com.ghazal.app.ACTION_BIRTHDAY"
    }
}
