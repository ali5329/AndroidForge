package com.ghazal.app.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.ghazal.app.MainActivity
import com.ghazal.app.R

object NotifHelper {
    const val CHANNEL_MSG = "ghazal_messages_v1"
    const val CHANNEL_BDAY = "ghazal_birthday_v1"
    const val GROUP = "com.ghazal.app.MSG"
    const val SUMMARY_ID = 2999

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        val sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        nm.createNotificationChannel(NotificationChannel(CHANNEL_MSG,
            context.getString(R.string.notification_channel_name),
            NotificationManager.IMPORTANCE_HIGH).apply {
            description = context.getString(R.string.notification_channel_desc)
            setSound(sound, attrs); enableVibration(true); setShowBadge(true)
        })
        nm.createNotificationChannel(NotificationChannel(CHANNEL_BDAY,
            context.getString(R.string.birthday_channel_name),
            NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(sound, attrs); enableVibration(true); setShowBadge(true)
        })
    }

    fun showMessage(context: Context, content: String, messageId: Long, unread: Int) {
        ensureChannels(context)
        val open = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("message_id", messageId)
        }
        val pi = PendingIntent.getActivity(context, messageId.toInt().and(0x7FFFFFFF), open,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val n = NotificationCompat.Builder(context, CHANNEL_MSG)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("غزل ❤️")
            .setContentText(content)
            .setStyle(NotificationCompat.BigTextStyle().bigText(content))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .setSound(sound)
            .setVibrate(longArrayOf(0, 300, 200, 300))
            .setGroup(GROUP)
            .setNumber(unread)
            .build()
        val summary = NotificationCompat.Builder(context, CHANNEL_MSG)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("غزل ❤️")
            .setContentText("$unread پیام جدید")
            .setStyle(NotificationCompat.InboxStyle().setSummaryText("$unread پیام خوانده‌نشده"))
            .setGroup(GROUP).setGroupSummary(true).setNumber(unread)
            .setAutoCancel(true).setContentIntent(pi).setSound(null).build()
        try {
            NotificationManagerCompat.from(context).notify((3000 + messageId % 40000).toInt(), n)
            NotificationManagerCompat.from(context).notify(SUMMARY_ID, summary)
        } catch (_: SecurityException) { }
    }

    fun showBirthday(context: Context) {
        ensureChannels(context)
        val open = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("open_birthday", true)
        }
        val pi = PendingIntent.getActivity(context, 9999, open,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val n = NotificationCompat.Builder(context, CHANNEL_BDAY)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("غزل، یه اتفاق قشنگ منتظرته! ❤️")
            .setContentText("غزل جان، امروز روز خاص توئه. تولدت مبارک! 🎂")
            .setStyle(NotificationCompat.BigTextStyle()
                .bigText("غزل جان، امروز روز خاص توئه. تولدت مبارک! 🎂"))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .setSound(sound)
            .setVibrate(longArrayOf(0, 400, 200, 400, 200, 400))
            .build()
        try {
            NotificationManagerCompat.from(context).notify(8888, n)
        } catch (_: SecurityException) { }
    }

    fun clearBadge(context: Context) {
        try { NotificationManagerCompat.from(context).cancel(SUMMARY_ID) } catch (_: Exception) { }
    }
}
