// ====== تنظیمات — با اپ چت یکی باشد ======
const firebaseConfig = {
  apiKey: "AIzaSyBWkd5Zi_1Pb9zThRGun69VcOwYaNyDckw",
  authDomain: "sample-firebase-ai-app-f211a.firebaseapp.com",
  databaseURL: "https://sample-firebase-ai-app-f211a-default-rtdb.firebaseio.com",
  projectId: "sample-firebase-ai-app-f211a",
  storageBucket: "sample-firebase-ai-app-f211a.firebasestorage.app",
  messagingSenderId: "689511797055",
  appId: "1:689511797055:web:5269152f011d284962438a"
};

// رمز پنل ادمین را اینجا عوض کنید
const ADMIN_PASSWORD = "classik2026";

firebase.initializeApp(firebaseConfig);
const db = firebase.database();
const messagesRef = db.ref('messages');
const adminsRef = db.ref('admins');

const loginView = document.getElementById('login-view');
const panelView = document.getElementById('panel-view');
const adminPass = document.getElementById('admin-pass');
const loginBtn = document.getElementById('login-btn');
const loginError = document.getElementById('login-error');
const logoutBtn = document.getElementById('logout-btn');
const msgList = document.getElementById('msg-list');
const statCount = document.getElementById('stat-count');
const statSize = document.getElementById('stat-size');
const filterType = document.getElementById('filter-type');
const searchMsg = document.getElementById('search-msg');
const cleanupResult = document.getElementById('cleanup-result');
const adminListEl = document.getElementById('admin-list');

let allMessages = []; // { id, ...data }

if (sessionStorage.getItem('classikAdmin') === '1') {
  showPanel();
}

loginBtn.addEventListener('click', tryLogin);
adminPass.addEventListener('keydown', (e) => { if (e.key === 'Enter') tryLogin(); });

function tryLogin() {
  if (adminPass.value === ADMIN_PASSWORD) {
    sessionStorage.setItem('classikAdmin', '1');
    loginError.classList.add('hidden');
    showPanel();
  } else {
    loginError.classList.remove('hidden');
  }
}

logoutBtn.addEventListener('click', () => {
  sessionStorage.removeItem('classikAdmin');
  panelView.classList.remove('active');
  loginView.classList.add('active');
  adminPass.value = '';
});

function showPanel() {
  loginView.classList.remove('active');
  panelView.classList.add('active');
  loadMessages();
  loadAdmins();
}

// Tabs
document.querySelectorAll('.tab').forEach((tab) => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((t) => t.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach((p) => p.classList.remove('active'));
    tab.classList.add('active');
    const panel = document.getElementById('tab-' + tab.dataset.tab);
    if (panel) panel.classList.add('active');
    if (tab.dataset.tab === 'chat' && typeof startAdminLiveChat === 'function') {
      setTimeout(startAdminLiveChat, 30);
    }
  });
});

function toPersianNum(n) {
  const p = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
  return String(n).replace(/\d/g, (d) => p[d]);
}

function formatTime(ts) {
  if (!ts) return '—';
  const d = new Date(ts);
  return d.toLocaleString('fa-IR');
}

function approxSize(obj) {
  try {
    return new Blob([JSON.stringify(obj)]).size;
  } catch {
    return JSON.stringify(obj).length;
  }
}

function formatBytes(b) {
  if (b < 1024) return b + ' B';
  if (b < 1024 * 1024) return (b / 1024).toFixed(1) + ' KB';
  return (b / (1024 * 1024)).toFixed(2) + ' MB';
}

function loadMessages() {
  msgList.innerHTML = '<p class="hint">در حال بارگذاری...</p>';
  messagesRef.once('value', (snap) => {
    allMessages = [];
    let totalSize = 0;
    if (snap.exists()) {
      snap.forEach((c) => {
        const val = c.val() || {};
        allMessages.push({ id: c.key, ...val });
        totalSize += approxSize(val);
      });
    }
    allMessages.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
    statCount.textContent = toPersianNum(allMessages.length) + ' پیام';
    statSize.textContent = 'حجم تقریبی: ' + formatBytes(totalSize);
    renderMessages();
  }, (err) => {
    msgList.innerHTML = '<p class="error">خطا در اتصال به دیتابیس</p>';
    console.error(err);
  });
}

document.getElementById('refresh-msg').addEventListener('click', loadMessages);
filterType.addEventListener('change', renderMessages);
searchMsg.addEventListener('input', renderMessages);

function renderMessages() {
  const type = filterType.value;
  const q = (searchMsg.value || '').trim().toLowerCase();
  let list = allMessages.filter((m) => {
    if (type === 'text' && (m.imageUrl || m.imageBase64 || m.voiceUrl)) return false;
    if (type === 'image' && !(m.imageUrl || m.imageBase64)) return false;
    if (type === 'voice' && !m.voiceUrl) return false;
    if (q) {
      const hay = ((m.text || '') + ' ' + (m.name || '') + ' ' + (m.userId || '')).toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });

  if (!list.length) {
    msgList.innerHTML = '<p class="hint">پیامی یافت نشد.</p>';
    return;
  }

  msgList.innerHTML = list.map((m) => {
    const tags = [];
    if (m.imageUrl || m.imageBase64) tags.push('<span class="tag image">عکس</span>');
    if (m.voiceUrl) tags.push('<span class="tag voice">ویس</span>');
    if (m.isAdmin) tags.push('<span class="tag">مدیر</span>');
    if (m.edited) tags.push('<span class="tag">ویرایش‌شده</span>');

    let body = '';
    if (m.text) body += `<div>${escapeHtml(m.text)}</div>`;
    const img = m.imageUrl || m.imageBase64;
    if (img) body += `<img src="${escapeAttr(img)}" class="preview-img" alt="عکس">`;
    if (m.voiceUrl) {
      body += `<div class="audio-row"><audio controls preload="none" src="${escapeAttr(m.voiceUrl)}"></audio></div>`;
    }
    if (!body) body = '<div class="hint">بدون محتوا</div>';

    return `<div class="msg-item" data-id="${escapeAttr(m.id)}">
      <div class="msg-head">
        <span class="name">${escapeHtml(m.name || '—')}</span>
        ${tags.join('')}
        <span>${formatTime(m.timestamp)}</span>
        <span class="uid" title="کپی userId" data-uid="${escapeAttr(m.userId || '')}">${escapeHtml(m.userId || '—')}</span>
      </div>
      <div class="msg-body">${body}</div>
      <div class="msg-actions">
        <button type="button" class="del" data-del="${escapeAttr(m.id)}">حذف</button>
      </div>
    </div>`;
  }).join('');

  msgList.querySelectorAll('.uid').forEach((el) => {
    el.addEventListener('click', () => {
      const u = el.dataset.uid;
      if (u && navigator.clipboard) navigator.clipboard.writeText(u);
      el.textContent = 'کپی شد!';
      setTimeout(() => { el.textContent = u; }, 1000);
    });
  });
  msgList.querySelectorAll('[data-del]').forEach((btn) => {
    btn.addEventListener('click', () => deleteOne(btn.dataset.del));
  });
  msgList.querySelectorAll('.preview-img').forEach((img) => {
    img.addEventListener('click', () => {
      document.getElementById('lb-img').src = img.src;
      document.getElementById('preview-lightbox').classList.remove('hidden');
    });
  });
}

document.getElementById('lb-close').addEventListener('click', () => {
  document.getElementById('preview-lightbox').classList.add('hidden');
});

function escapeHtml(s) {
  const d = document.createElement('div');
  d.textContent = s || '';
  return d.innerHTML;
}
function escapeAttr(s) {
  return String(s || '').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;');
}

async function deleteOne(id) {
  if (!confirm('این پیام حذف شود؟')) return;
  await messagesRef.child(id).remove();
  allMessages = allMessages.filter((m) => m.id !== id);
  statCount.textContent = toPersianNum(allMessages.length) + ' پیام';
  renderMessages();
}

// Cleanup
function rangeBounds(range) {
  const now = Date.now();
  const day = 24 * 60 * 60 * 1000;
  if (range === 'day') return { from: now - day, to: now };
  if (range === 'week') return { from: now - 7 * day, to: now };
  if (range === 'month') return { from: now - 30 * day, to: now };
  if (range === 'all') return { from: 0, to: Infinity };
  return null;
}

async function cleanupByRange(from, to) {
  cleanupResult.textContent = 'در حال حذف...';
  const snap = await messagesRef.once('value');
  const updates = {};
  let count = 0;
  snap.forEach((c) => {
    const ts = (c.val() && c.val().timestamp) || 0;
    if (ts >= from && ts <= to) {
      updates[c.key] = null;
      count++;
    }
  });
  if (count === 0) {
    cleanupResult.textContent = 'پیامی در این بازه نبود.';
    return;
  }
  if (!confirm(count + ' پیام حذف شود؟ این کار برگشت‌ناپذیر است.')) {
    cleanupResult.textContent = 'لغو شد.';
    return;
  }
  await messagesRef.update(updates);
  cleanupResult.textContent = count + ' پیام حذف شد. دیتابیس سبک‌تر شد.';
  loadMessages();
}

document.querySelectorAll('.cleanup-btn').forEach((btn) => {
  btn.addEventListener('click', () => {
    const b = rangeBounds(btn.dataset.range);
    if (b) cleanupByRange(b.from, b.to);
  });
});

document.getElementById('cleanup-custom').addEventListener('click', () => {
  const fromEl = document.getElementById('from-date').value;
  const toEl = document.getElementById('to-date').value;
  if (!fromEl || !toEl) {
    cleanupResult.textContent = 'هر دو تاریخ را انتخاب کنید.';
    return;
  }
  const from = new Date(fromEl).setHours(0, 0, 0, 0);
  const to = new Date(toEl).setHours(23, 59, 59, 999);
  cleanupByRange(from, to);
});

// Admins
function loadAdmins() {
  adminsRef.on('value', (snap) => {
    const items = [];
    if (snap.exists()) {
      snap.forEach((c) => {
        const v = c.val();
        items.push({ id: c.key, name: (v && v.name) || '' });
      });
    }
    if (!items.length) {
      adminListEl.innerHTML = '<p class="hint">مدیری ثبت نشده.</p>';
      return;
    }
    adminListEl.innerHTML = items.map((a) => `
      <div class="admin-item">
        <div>
          <strong>${escapeHtml(a.name || 'مدیر')}</strong>
          <div class="uid">${escapeHtml(a.id)}</div>
        </div>
        <button type="button" data-rm="${escapeAttr(a.id)}">حذف</button>
      </div>
    `).join('');
    adminListEl.querySelectorAll('[data-rm]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        if (!confirm('این مدیر حذف شود؟')) return;
        await adminsRef.child(btn.dataset.rm).remove();
      });
    });
  });
}

document.getElementById('add-admin').addEventListener('click', async () => {
  const id = document.getElementById('admin-userid').value.trim();
  const name = document.getElementById('admin-name').value.trim();
  if (!id) return alert('userId لازم است');
  await adminsRef.child(id).set({ name: name || 'مدیر', addedAt: Date.now() });
  document.getElementById('admin-userid').value = '';
  document.getElementById('admin-name').value = '';
});


// ===== چت زنده ادمین (شبیه اپ) =====
const alcMessages = document.getElementById('alc-messages');
const alcForm = document.getElementById('alc-form');
const alcInput = document.getElementById('alc-input');
let alcListener = null;
let alcInitial = true;

function alcEscape(s) {
  const d = document.createElement('div');
  d.textContent = s || '';
  return d.innerHTML;
}

function alcTime(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  const h = d.getHours().toString().padStart(2, '0');
  const m = d.getMinutes().toString().padStart(2, '0');
  return h + ':' + m;
}

function alcAppend(msg, id) {
  if (!alcMessages || !msg) return;
  if (document.querySelector('.alc-msg[data-id="' + id + '"]')) return;
  const empty = alcMessages.querySelector('.alc-empty');
  if (empty) empty.remove();

  const adminId = (document.getElementById('admin-chat-id') || {}).value || 'admin_classik';
  const isMe = msg.userId === adminId || msg.isAdmin;
  const isAdmin = !!(msg.isAdmin || msg.userId === adminId);
  const div = document.createElement('div');
  div.className = 'alc-msg ' + (isMe ? 'me' : 'other') + (isAdmin ? ' admin' : '');
  div.dataset.id = id;

  let body = '';
  if (msg.text) body += '<div>' + alcEscape(msg.text) + '</div>';
  const img = msg.imageUrl || msg.imageBase64;
  if (img) body += '<img src="' + alcEscape(img) + '" alt="">';
  if (msg.voiceUrl) body += '<div>🎤 ویس</div>';
  if (!body) body = '<div style="opacity:.6">—</div>';

  const badge = isAdmin ? '<span class="alc-badge">مدیر</span><span class="alc-tick">✓</span>' : '';
  div.innerHTML =
    '<div class="alc-meta">' +
      '<span class="alc-name">' + alcEscape(msg.name || '—') + '</span>' +
      badge +
      '<span class="alc-time">' + alcTime(msg.timestamp) + '</span>' +
    '</div>' +
    '<div class="alc-bubble">' + body + '</div>';
  alcMessages.appendChild(div);
  alcMessages.scrollTop = alcMessages.scrollHeight;
}

function startAdminLiveChat() {
  if (!alcMessages) return;
  if (alcListener) {
    messagesRef.off('child_added', alcListener);
    alcListener = null;
  }
  alcMessages.innerHTML = '<div class="alc-empty">در حال بارگذاری گفتگو...</div>';
  alcInitial = true;
  messagesRef.limitToLast(80).once('value', (snap) => {
    alcMessages.innerHTML = '';
    if (!snap.exists()) {
      alcMessages.innerHTML = '<div class="alc-empty">هنوز پیامی در گروه نیست.<br>اولین پیام مدیر را بفرستید 👑</div>';
    } else {
      snap.forEach((c) => alcAppend(c.val(), c.key));
      alcMessages.scrollTop = alcMessages.scrollHeight;
    }
    alcInitial = false;
    alcListener = messagesRef.limitToLast(80).on('child_added', (s) => {
      if (document.querySelector('.alc-msg[data-id="' + s.key + '"]')) return;
      alcAppend(s.val(), s.key);
    });
  }, () => {
    alcMessages.innerHTML = '<div class="alc-empty">خطا در اتصال به دیتابیس</div>';
  });
}

if (alcForm) {
  alcForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = ((document.getElementById('admin-chat-name') || {}).value || '').trim() || 'مدیر Classik';
    const userId = ((document.getElementById('admin-chat-id') || {}).value || '').trim() || 'admin_classik';
    const text = (alcInput.value || '').trim();
    if (!text) return;
    const btn = document.getElementById('alc-send');
    if (btn) btn.disabled = true;
    try {
      await messagesRef.push({
        text,
        name,
        userId,
        isAdmin: true,
        status: 'sent',
        timestamp: firebase.database.ServerValue.TIMESTAMP
      });
      await adminsRef.child(userId).set({ name, addedAt: Date.now() });
      alcInput.value = '';
      alcInput.focus();
    } catch (err) {
      console.error(err);
      alert('ارسال ناموفق بود. اتصال و قوانین دیتابیس را بررسی کنید.');
    } finally {
      if (btn) btn.disabled = false;
    }
  });
}


