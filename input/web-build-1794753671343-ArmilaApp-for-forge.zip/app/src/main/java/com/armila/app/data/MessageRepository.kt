package com.armila.app.data

import android.content.Context
import com.armila.app.util.MessageGenerator
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class MessageRepository(context: Context) {

    private val dao = AppDatabase.getInstance(context).messageDao()
    private val prefs = PreferencesManager(context)

    val allMessages: Flow<List<MessageEntity>> = dao.getAllMessages()
    val latestMessage: Flow<MessageEntity?> = dao.getLatestMessage()
    val messageCount: Flow<Int> = dao.getMessageCount()
    val nextIndexFlow: Flow<Long> = prefs.nextMessageIndex
    val lastNotificationTime: Flow<Long> = prefs.lastNotificationTime
    val unreadCount: Flow<Int> = prefs.unreadCount

    suspend fun getNextIndex(): Long = prefs.nextMessageIndex.first()

    /**
     * Generates the next unique message, stores it, advances the index,
     * increments unread badge count, and returns the new entity + unread count.
     */
    suspend fun deliverNextMessage(): Pair<MessageEntity, Int> {
        val index = prefs.nextMessageIndex.first()
        val content = MessageGenerator.generate(index)
        val entity = MessageEntity(
            messageIndex = index,
            content = content,
            receivedAt = System.currentTimeMillis()
        )
        dao.insert(entity)
        val next = MessageGenerator.nextIndex(index)
        prefs.setNextMessageIndex(next)
        prefs.setLastNotificationTime(System.currentTimeMillis())
        val unread = prefs.incrementUnreadCount()
        return entity to unread
    }

    suspend fun markFirstLaunchDone() {
        prefs.setFirstLaunchDone()
    }

    suspend fun isFirstLaunchDone(): Boolean = prefs.isFirstLaunchDone.first()

    suspend fun clearUnread() {
        prefs.clearUnreadCount()
    }
}
