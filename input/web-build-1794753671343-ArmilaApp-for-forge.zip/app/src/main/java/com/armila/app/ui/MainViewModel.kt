package com.armila.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.armila.app.data.MessageEntity
import com.armila.app.data.MessageRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = MessageRepository(application)

    val latestMessage: StateFlow<MessageEntity?> = repository.latestMessage
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allMessages: StateFlow<List<MessageEntity>> = repository.allMessages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val messageCount: StateFlow<Int> = repository.messageCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val nextIndex: StateFlow<Long> = repository.nextIndexFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val lastNotificationTime: StateFlow<Long> = repository.lastNotificationTime
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)
}
