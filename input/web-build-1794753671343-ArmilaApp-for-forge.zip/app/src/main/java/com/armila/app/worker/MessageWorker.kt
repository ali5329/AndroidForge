package com.armila.app.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.armila.app.MainActivity
import com.armila.app.R
import com.armila.app.data.MessageRepository
import java.util.concurrent.TimeUnit

/**
 * Delivers one romantic message and then reschedules itself after [INTERVAL_MINUTES].
 * Uses a notification group + summary so the launcher badge shows the correct unread count.
 * Custom notification sound: res/raw/armila_notif.mp3
 */
class MessageWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            val repository = MessageRepository(applicationContext)
            val (message, unreadCount) = repository.deliverNextMessage()

            showNotification(message.content, message.id, unreadCount)

            scheduleNext(applicationContext)
            Result.success()
        } catch (e: Exception) {
            e.printStackTrace()
            scheduleNext(applicationContext)
            Result.retry()
        }
    }

    private fun showNotification(content: String, messageId: Long, unreadCount: Int) {
        createChannel()

        val soundUri = Uri.parse("android.resource://${applicationContext.packageName}/${R.raw.armila_notif}")

        val intent = Intent(applicationContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(EXTRA_MESSAGE_ID, messageId)
            data = Uri.parse("armila://message/$messageId")
        }

        val pendingIntent = PendingIntent.getActivity(
            applicationContext,
            messageId.toInt().and(0x7FFFFFFF),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notifId = (NOTIFICATION_ID_BASE + (messageId % 40_000)).toInt()

        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("آرمیلا ❤️")
            .setContentText(content)
            .setStyle(NotificationCompat.BigTextStyle().bigText(content))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setSound(soundUri)
            .setVibrate(longArrayOf(0, 300, 200, 300))
            .setOnlyAlertOnce(false)
            .setGroup(GROUP_KEY)
            .setNumber(unreadCount)
            .build()

        val summaryIntent = Intent(applicationContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val summaryPending = PendingIntent.getActivity(
            applicationContext,
            0,
            summaryIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val summary = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("آرمیلا ❤️")
            .setContentText("$unreadCount پیام عاشقانه جدید")
            .setStyle(
                NotificationCompat.InboxStyle()
                    .setSummaryText("$unreadCount پیام خوانده‌نشده")
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .setContentIntent(summaryPending)
            .setGroup(GROUP_KEY)
            .setGroupSummary(true)
            .setNumber(unreadCount)
            .setOnlyAlertOnce(true)
            .setSound(null) // summary should not play sound again
            .build()

        with(NotificationManagerCompat.from(applicationContext)) {
            try {
                notify(notifId, notification)
                notify(SUMMARY_ID, summary)
            } catch (_: SecurityException) {
            }
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val soundUri = Uri.parse("android.resource://${applicationContext.packageName}/${R.raw.armila_notif}")
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()

            val channel = NotificationChannel(
                CHANNEL_ID,
                applicationContext.getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = applicationContext.getString(R.string.notification_channel_desc)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 300, 200, 300)
                setSound(soundUri, attrs)
                setShowBadge(true)
            }
            val manager = applicationContext.getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    companion object {
        const val WORK_NAME = "armila_message_chain"
        // New channel ID so the custom sound is applied even if an old channel existed
        const val CHANNEL_ID = "armila_love_messages_v2"
        const val GROUP_KEY = "com.armila.app.MESSAGES"
        const val NOTIFICATION_ID_BASE = 2000
        const val SUMMARY_ID = 1999
        const val EXTRA_MESSAGE_ID = "extra_message_id"

        /** Production interval: 60 minutes */
        const val INTERVAL_MINUTES = 60L

        fun schedule(context: Context) {
            val request = OneTimeWorkRequestBuilder<MessageWorker>()
                .setInitialDelay(INTERVAL_MINUTES, TimeUnit.MINUTES)
                .addTag(WORK_NAME)
                .build()

            WorkManager.getInstance(context).enqueueUniqueWork(
                WORK_NAME,
                ExistingWorkPolicy.REPLACE,
                request
            )
        }

        fun scheduleNext(context: Context) {
            schedule(context)
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        }

        fun clearBadge(context: Context) {
            try {
                NotificationManagerCompat.from(context).cancel(SUMMARY_ID)
            } catch (_: Exception) { }
        }
    }
}
