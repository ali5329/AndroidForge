package com.armila.app.worker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Placeholder for future notification actions (e.g. dismiss, reply).
 * Currently notifications open the MainActivity directly via PendingIntent.
 */
class NotificationActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        // Reserved for future use
    }
}
