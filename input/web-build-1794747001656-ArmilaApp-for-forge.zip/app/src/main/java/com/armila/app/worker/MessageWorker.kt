package com.armila.app.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.armila.app.MainActivity
import com.armila.app.R
import com.armila.app.data.MessageRepository
import java.util.concurrent.TimeUnit

/**
 * Delivers one romantic message and then reschedules itself after [INTERVAL_MINUTES].
 * Using chained OneTimeWorkRequest is more reliable for short intervals than PeriodicWork.
 */
class MessageWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            val repository = MessageRepository(applicationContext)
            val message = repository.deliverNextMessage()

            showNotification(message.content, message.id)

            // Reschedule the next run
            scheduleNext(applicationContext)

            Result.success()
        } catch (e: Exception) {
            e.printStackTrace()
            // Still try to reschedule so the chain doesn't die
            scheduleNext(applicationContext)
            Result.retry()
        }
    }

    private fun showNotification(content: String, messageId: Long) {
        createChannel()

        val intent = Intent(applicationContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_MESSAGE_ID, messageId)
            data = Uri.parse("armila://message/$messageId")
        }

        val pendingIntent = PendingIntent.getActivity(
            applicationContext,
            messageId.toInt().and(0x7FFFFFFF), // keep positive
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        // Unique notification id so each message appears as a separate notification
        val notifId = (NOTIFICATION_ID_BASE + (messageId % 50_000)).toInt()

        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("آرمیلا ❤️")
            .setContentText(content)
            .setStyle(NotificationCompat.BigTextStyle().bigText(content))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setSound(soundUri)
            .setVibrate(longArrayOf(0, 300, 200, 300))
            .setOnlyAlertOnce(false)
            .build()

        with(NotificationManagerCompat.from(applicationContext)) {
            try {
                notify(notifId, notification)
            } catch (_: SecurityException) {
                // Permission not granted
            }
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                applicationContext.getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = applicationContext.getString(R.string.notification_channel_desc)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 300, 200, 300)
                setSound(
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setShowBadge(true)
            }
            val manager = applicationContext.getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    companion object {
        const val WORK_NAME = "armila_message_chain"
        const val CHANNEL_ID = "armila_love_messages"
        const val NOTIFICATION_ID_BASE = 2000
        const val EXTRA_MESSAGE_ID = "extra_message_id"

        /** TEST INTERVAL – change to 60 for production (1 hour) */
        const val INTERVAL_MINUTES = 1L

        fun schedule(context: Context) {
            val request = OneTimeWorkRequestBuilder<MessageWorker>()
                .setInitialDelay(INTERVAL_MINUTES, TimeUnit.MINUTES)
                .addTag(WORK_NAME)
                .build()

            WorkManager.getInstance(context).enqueueUniqueWork(
                WORK_NAME,
                ExistingWorkPolicy.REPLACE,
                request
            )
        }

        fun scheduleNext(context: Context) {
            schedule(context)
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        }
    }
}
